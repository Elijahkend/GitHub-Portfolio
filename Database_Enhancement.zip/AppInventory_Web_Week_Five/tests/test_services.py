"""
AppInventory Web Enhancement
Author: Elija Kwembe
Date: August 10, 2026
Course: CS 499 Computer Science Capstone
Purpose: Test authentication, validation, ownership, ranked search,
         literal wildcard handling, summaries, pagination, and audit history.
"""

import sqlite3
import tempfile
import unittest
from pathlib import Path

from database import Database
from services import AuthService, InventoryService


class AppInventoryServiceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_directory = tempfile.TemporaryDirectory()
        self.database = Database(Path(self.temp_directory.name) / "test.db")
        self.database.initialize()
        self.auth = AuthService(self.database)
        self.inventory = InventoryService(self.database)

    def tearDown(self) -> None:
        self.temp_directory.cleanup()

    def registration_form(self, username: str, email: str) -> dict[str, str]:
        return {
            "first_name": "Alex",
            "last_name": "Carter",
            "username": username,
            "email": email,
            "date_of_birth": "1990-01-01",
            "password": "StrongPass1",
            "confirm_password": "StrongPass1",
        }

    def test_registration_hashes_password_and_login_works(self) -> None:
        user_id, errors = self.auth.register(self.registration_form("alex1", "alex@example.com"))
        self.assertIsNotNone(user_id)
        self.assertEqual([], errors)

        with self.database.connect() as connection:
            row = connection.execute("SELECT password_hash FROM users WHERE id = ?", (user_id,)).fetchone()
        self.assertNotEqual("StrongPass1", row["password_hash"])

        session, login_errors = self.auth.login({"identity": "alex1", "password": "StrongPass1"})
        self.assertIsNotNone(session)
        self.assertEqual([], login_errors)

    def test_duplicate_account_is_rejected(self) -> None:
        self.auth.register(self.registration_form("alex1", "alex@example.com"))
        user_id, errors = self.auth.register(self.registration_form("alex1", "other@example.com"))
        self.assertIsNone(user_id)
        self.assertTrue(errors)

    def test_inventory_is_separated_by_user(self) -> None:
        first_id, _ = self.auth.register(self.registration_form("alex1", "alex@example.com"))
        second_id, _ = self.auth.register(self.registration_form("student2", "student2@example.com"))
        self.inventory.add_item(first_id, {"name": "Laptop", "quantity": "4", "low_stock_threshold": "2"})

        self.assertEqual(1, len(self.inventory.list_items(first_id)))
        self.assertEqual(0, len(self.inventory.list_items(second_id)))

        item = self.inventory.list_items(first_id)[0]
        self.assertFalse(self.inventory.delete_item(item.id, second_id))
        self.assertEqual(1, len(self.inventory.list_items(first_id)))

    def test_negative_quantity_is_rejected(self) -> None:
        user_id, _ = self.auth.register(self.registration_form("alex1", "alex@example.com"))
        errors = self.inventory.add_item(user_id, {"name": "Laptop", "quantity": "-1", "low_stock_threshold": "2"})
        self.assertTrue(errors)
        self.assertEqual([], self.inventory.list_items(user_id))


    def add_named_item(
        self,
        user_id: int,
        name: str,
        quantity: str = "1",
        low_stock_threshold: str = "0",
    ) -> None:
        """Add one valid inventory item for search tests."""

        errors = self.inventory.add_item(
            user_id,
            {
                "name": name,
                "quantity": quantity,
                "low_stock_threshold": low_stock_threshold,
            },
        )
        self.assertEqual([], errors)

    def test_search_is_case_insensitive_and_ranks_exact_match_first(self) -> None:
        user_id, _ = self.auth.register(
            self.registration_form("alex1", "alex@example.com")
        )
        self.add_named_item(user_id, "Wireless Mouse")
        self.add_named_item(user_id, "Mouse Pad")
        self.add_named_item(user_id, "Mouse")
        self.add_named_item(user_id, "Office MOUSE Stand")
        self.add_named_item(user_id, "Keyboard")

        result = self.inventory.search_items(user_id, "  mouse  ")
        names = [item.name for item in result.items]

        self.assertEqual(4, result.total_matches)
        self.assertEqual("mouse", result.query)
        self.assertEqual("Mouse", names[0])
        self.assertEqual("Mouse Pad", names[1])
        self.assertNotIn("Keyboard", names)

    def test_search_returns_only_records_owned_by_the_user(self) -> None:
        first_id, _ = self.auth.register(
            self.registration_form("alex1", "alex@example.com")
        )
        second_id, _ = self.auth.register(
            self.registration_form("student2", "student2@example.com")
        )
        self.add_named_item(first_id, "Shared Name Item")
        self.add_named_item(second_id, "Shared Name Item")

        first_result = self.inventory.search_items(first_id, "shared")
        second_result = self.inventory.search_items(second_id, "shared")

        self.assertEqual(1, first_result.total_matches)
        self.assertEqual(1, second_result.total_matches)
        self.assertEqual(first_id, first_result.items[0].user_id)
        self.assertEqual(second_id, second_result.items[0].user_id)

    def test_search_treats_sql_wildcards_as_literal_characters(self) -> None:
        user_id, _ = self.auth.register(
            self.registration_form("alex1", "alex@example.com")
        )
        self.add_named_item(user_id, "100% Cotton")
        self.add_named_item(user_id, "100X Cotton")
        self.add_named_item(user_id, "Shelf_A")
        self.add_named_item(user_id, "ShelfXA")

        percent_result = self.inventory.search_items(user_id, "100%")
        underscore_result = self.inventory.search_items(user_id, "Shelf_")

        self.assertEqual(
            ["100% Cotton"],
            [item.name for item in percent_result.items],
        )
        self.assertEqual(
            ["Shelf_A"],
            [item.name for item in underscore_result.items],
        )

    def test_search_pagination_limits_each_result_page(self) -> None:
        user_id, _ = self.auth.register(
            self.registration_form("alex1", "alex@example.com")
        )

        for number in range(1, 16):
            self.add_named_item(user_id, f"Cable {number:02d}")

        second_page = self.inventory.search_items(
            user_id,
            "Cable",
            page=2,
            page_size=5,
        )
        corrected_page = self.inventory.search_items(
            user_id,
            "Cable",
            page=99,
            page_size=5,
        )

        self.assertEqual(15, second_page.total_matches)
        self.assertEqual(3, second_page.total_pages)
        self.assertEqual(5, len(second_page.items))
        self.assertEqual(6, second_page.first_result_number)
        self.assertEqual(10, second_page.last_result_number)
        self.assertEqual(3, corrected_page.page)

    def test_inventory_summary_uses_all_user_records(self) -> None:
        user_id, _ = self.auth.register(
            self.registration_form("alex1", "alex@example.com")
        )
        self.add_named_item(user_id, "Available", "10", "2")
        self.add_named_item(user_id, "Low", "2", "3")
        self.add_named_item(user_id, "Empty", "0", "5")

        summary = self.inventory.get_summary(user_id)

        self.assertEqual(3, summary.record_count)
        self.assertEqual(12, summary.total_units)
        self.assertEqual(1, summary.low_stock)
        self.assertEqual(1, summary.out_of_stock)

    def test_activity_report_records_add_update_and_delete(self) -> None:
        user_id, _ = self.auth.register(
            self.registration_form("alex1", "alex@example.com")
        )
        self.add_named_item(user_id, "Scanner", "4", "2")
        item = self.inventory.list_items(user_id)[0]

        errors = self.inventory.update_item(
            item.id,
            user_id,
            {"name": "Scanner", "quantity": "7", "low_stock_threshold": "2"},
        )
        self.assertEqual([], errors)
        self.assertTrue(self.inventory.delete_item(item.id, user_id))

        report = self.inventory.get_activity_report(user_id)
        self.assertEqual((1, 1, 1), (report.added, report.updated, report.deleted))
        self.assertEqual("DELETED", report.recent[0].action)
        self.assertEqual("Scanner", report.recent[0].item_name)
        self.assertIsNone(report.recent[0].item_id)

    def test_activity_report_is_separated_by_user(self) -> None:
        first_id, _ = self.auth.register(
            self.registration_form("alex1", "alex@example.com")
        )
        second_id, _ = self.auth.register(
            self.registration_form("student2", "student2@example.com")
        )
        self.add_named_item(first_id, "Private Item")

        first_report = self.inventory.get_activity_report(first_id)
        second_report = self.inventory.get_activity_report(second_id)

        self.assertEqual(1, first_report.added)
        self.assertEqual(0, second_report.added)
        self.assertEqual((), second_report.recent)


if __name__ == "__main__":
    unittest.main()
