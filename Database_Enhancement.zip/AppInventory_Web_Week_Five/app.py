"""
AppInventory Web Enhancement
Author: Elija Kwembe
Date: August 10, 2026
Course: CS 499 Computer Science Capstone
Purpose: Enhance the browser based inventory application with ranked,
         database side searching, audit history, and reporting while
         preserving secure, separated application layers.
"""

# Provides standard HTTP status codes.
from http import HTTPStatus

# Reads browser cookies.
from http.cookies import SimpleCookie

# Creates safe file paths.
from pathlib import Path

# Provides type hints for route functions.
from typing import Callable

# Reads forms, query strings, and URL paths.
from urllib.parse import parse_qs, urlencode, urlparse

# Creates the local web server.
from wsgiref.simple_server import make_server

# Imports application settings.
import config

# Imports the database layer.
from database import Database

# Imports authentication and inventory services.
from services import AuthService, InventoryService, SessionData

# Imports HTML page functions.
from templates import (
    dashboard_page,
    edit_item_page,
    error_page,
    login_page,
    register_page,
)


# Name of the browser cookie used for login sessions.
SESSION_COOKIE = "appinventory_session"

# Creates the shared database object.
database = Database(config.DATABASE_PATH)

# Creates the authentication service.
auth_service = AuthService(database)

# Creates the inventory service.
inventory_service = InventoryService(database)


class Response:
    """Stores the body, status, and headers for a web response."""

    def __init__(
        self,
        body: str | bytes = "",
        status: HTTPStatus = HTTPStatus.OK,
        headers: list[tuple[str, str]] | None = None,
    ):
        # Converts text into bytes because WSGI requires bytes.
        self.body = body.encode("utf-8") if isinstance(body, str) else body

        # Stores the HTTP response status.
        self.status = status

        # Stores headers such as cookies and content types.
        self.headers = headers or []

    @classmethod
    def redirect(
        cls,
        location: str,
        headers: list[tuple[str, str]] | None = None,
    ) -> "Response":
        """Send the browser to another page."""

        # Adds the new page location to the response.
        response_headers = [("Location", location)]

        # Adds optional headers such as a login cookie.
        if headers:
            response_headers.extend(headers)

        # Creates a redirect response.
        return cls(
            b"",
            HTTPStatus.SEE_OTHER,
            response_headers,
        )


def read_form(environ: dict) -> dict[str, str]:
    """Read submitted form information."""

    try:
        # Limits the size of submitted form data.
        length = min(
            int(environ.get("CONTENT_LENGTH") or 0),
            100_000,
        )
    except ValueError:
        length = 0

    # Reads and decodes the form body.
    raw = environ["wsgi.input"].read(length).decode(
        "utf-8",
        errors="replace",
    )

    # Converts the form body into a dictionary.
    parsed = parse_qs(
        raw,
        keep_blank_values=True,
    )

    # Returns one value for each form field.
    return {
        key: values[-1]
        for key, values in parsed.items()
    }


def session_token(environ: dict) -> str | None:
    """Read the login token from the browser cookie."""

    # Creates a cookie reader.
    cookie = SimpleCookie()

    # Loads cookies sent by the browser.
    cookie.load(
        environ.get("HTTP_COOKIE", "")
    )

    # Gets the application session cookie.
    morsel = cookie.get(SESSION_COOKIE)

    # Returns the token when it exists.
    return morsel.value if morsel else None


def active_session(environ: dict) -> SessionData | None:
    """Return the current active session."""

    # Checks the browser token against stored sessions.
    return auth_service.get_session(
        session_token(environ)
    )


def valid_csrf(
    form: dict[str, str],
    session: SessionData,
) -> bool:
    """Check the form security token."""

    # Confirms that the submitted token matches the session.
    return (
        form.get("csrf_token", "")
        == session.csrf_token
    )


def require_session(
    environ: dict,
) -> SessionData | Response:
    """Require the user to be signed in."""

    # Checks for an active login session.
    session = active_session(environ)

    # Sends unsigned users to the login page.
    if session is None:
        return Response.redirect("/login")

    # Returns the active session.
    return session


def message_url(
    message: str,
    kind: str = "success",
) -> str:
    """Create a dashboard URL containing a message."""

    # Safely adds the message to the page URL.
    return "/dashboard?" + urlencode({
        "message": message,
        "kind": kind,
    })


def handle_index(environ: dict) -> Response:
    """Open the correct starting page."""

    # Signed in users go to the dashboard.
    if active_session(environ):
        return Response.redirect("/dashboard")

    # Other users go to the login page.
    return Response.redirect("/login")


def handle_login(environ: dict) -> Response:
    """Display or process the login page."""

    # Displays the login page for a GET request.
    if environ["REQUEST_METHOD"] == "GET":

        # Sends signed in users to the dashboard.
        if active_session(environ):
            return Response.redirect("/dashboard")

        # Reads an optional message from the URL.
        query = parse_qs(
            environ.get("QUERY_STRING", "")
        )

        # Returns the login page.
        return Response(
            login_page(
                message=query.get(
                    "message",
                    [""],
                )[0]
            )
        )

    # Reads the submitted login form.
    form = read_form(environ)

    # Checks the username and password.
    session, errors = auth_service.login(form)

    # Displays errors when login fails.
    if errors or session is None:
        return Response(
            login_page(errors=errors),
            HTTPStatus.UNAUTHORIZED,
        )

    # Creates the browser login cookie.
    cookie = (
        f"{SESSION_COOKIE}={session.token}; "
        f"Path=/; "
        f"HttpOnly; "
        f"SameSite=Lax; "
        f"Max-Age={config.SESSION_HOURS * 3600}"
    )

    # Sends the user to the dashboard.
    return Response.redirect(
        "/dashboard",
        [("Set-Cookie", cookie)],
    )


def handle_register(environ: dict) -> Response:
    """Display or process the registration page."""

    # Displays the registration form.
    if environ["REQUEST_METHOD"] == "GET":

        # Sends signed in users to the dashboard.
        if active_session(environ):
            return Response.redirect("/dashboard")

        return Response(register_page())

    # Reads the submitted registration form.
    form = read_form(environ)

    # Validates and creates the account.
    user_id, errors = auth_service.register(form)

    # Keeps safe form values when validation fails.
    safe_values = {
        key: value
        for key, value in form.items()
        if "password" not in key
    }

    # Displays registration errors.
    if errors or user_id is None:
        return Response(
            register_page(
                errors,
                safe_values,
            ),
            HTTPStatus.BAD_REQUEST,
        )

    # Sends the new user to the login page.
    return Response.redirect(
        "/login?"
        + urlencode({
            "message": (
                "Account created. "
                "You can now sign in."
            )
        })
    )


def handle_logout(environ: dict) -> Response:
    """End the current login session."""

    # Requires an active session.
    session = require_session(environ)

    if isinstance(session, Response):
        return session

    # Reads the logout form.
    form = read_form(environ)

    # Blocks requests with an invalid security token.
    if not valid_csrf(form, session):
        return Response(
            error_page(
                "Request blocked",
                "The security token was not valid.",
                session.user,
                session.csrf_token,
            ),
            HTTPStatus.FORBIDDEN,
        )

    # Deletes the stored session.
    auth_service.logout(session.token)

    # Removes the login cookie from the browser.
    cookie = (
        f"{SESSION_COOKIE}=; "
        f"Path=/; "
        f"HttpOnly; "
        f"SameSite=Lax; "
        f"Max-Age=0"
    )

    # Returns the user to the login page.
    return Response.redirect(
        "/login?"
        + urlencode({
            "message": "You have been signed out."
        }),
        [("Set-Cookie", cookie)],
    )


def positive_int(value: str, default: int = 1) -> int:
    """Return a positive integer or a safe default value."""

    try:
        parsed_value = int(value)
        return parsed_value if parsed_value > 0 else default
    except (TypeError, ValueError):
        return default


def handle_dashboard(environ: dict) -> Response:
    """Display a searchable page of the user's inventory dashboard."""

    # Requires an active session.
    session = require_session(environ)

    if isinstance(session, Response):
        return session

    # Reads search, page, and optional message values from the URL.
    query = parse_qs(
        environ.get("QUERY_STRING", ""),
        keep_blank_values=True,
    )

    search_text = query.get("q", [""])[0]
    page = positive_int(query.get("page", ["1"])[0])

    # Performs the search inside SQLite and returns only one result page.
    search_page = inventory_service.search_items(
        user_id=session.user.id,
        query=search_text,
        page=page,
    )

    # Calculates account totals separately from the filtered result page.
    summary = inventory_service.get_summary(session.user.id)
    activity_report = inventory_service.get_activity_report(session.user.id)

    message = query.get(
        "message",
        [""],
    )[0]

    kind = query.get(
        "kind",
        ["success"],
    )[0]

    # Returns the completed dashboard.
    return Response(
        dashboard_page(
            session.user,
            session.csrf_token,
            search_page,
            summary,
            activity_report,
            message=message,
            kind=kind,
        )
    )


def handle_add_item(environ: dict) -> Response:
    """Add a new inventory item."""

    # Requires an active session.
    session = require_session(environ)

    if isinstance(session, Response):
        return session

    # Reads the submitted inventory form.
    form = read_form(environ)

    # Checks the form security token.
    if not valid_csrf(form, session):
        return Response(
            error_page(
                "Request blocked",
                "The security token was not valid.",
                session.user,
                session.csrf_token,
            ),
            HTTPStatus.FORBIDDEN,
        )

    # Validates and saves the item.
    errors = inventory_service.add_item(
        session.user.id,
        form,
    )

    # Displays validation errors without loading an unlimited item list.
    if errors:
        search_page = inventory_service.search_items(
            session.user.id
        )
        summary = inventory_service.get_summary(
            session.user.id
        )
        activity_report = inventory_service.get_activity_report(
            session.user.id
        )

        return Response(
            dashboard_page(
                session.user,
                session.csrf_token,
                search_page,
                summary,
                activity_report,
                errors=errors,
                form_values=form,
            ),
            HTTPStatus.BAD_REQUEST,
        )

    # Returns to the dashboard after success.
    return Response.redirect(
        message_url("Inventory item added.")
    )


def get_item_id(
    values: dict[str, str],
) -> int | None:
    """Read and validate an inventory item ID."""

    try:
        # Supports IDs from forms and query strings.
        item_id = int(
            values.get(
                "item_id",
                values.get("id", ""),
            )
        )

        # Accepts only positive IDs.
        return item_id if item_id > 0 else None

    except ValueError:
        return None


def handle_edit_item(environ: dict) -> Response:
    """Display or process the inventory edit page."""

    # Requires an active session.
    session = require_session(environ)

    if isinstance(session, Response):
        return session

    # Displays the edit page.
    if environ["REQUEST_METHOD"] == "GET":

        # Reads the item ID from the URL.
        query = parse_qs(
            environ.get("QUERY_STRING", "")
        )

        item_id = get_item_id({
            "id": query.get("id", [""])[0]
        })

        # Loads the item only when it belongs to the user.
        item = inventory_service.get_item(
            item_id or 0,
            session.user.id,
        )

        # Displays an error when the item is missing.
        if item is None:
            return Response(
                error_page(
                    "Item not found",
                    (
                        "The item does not exist or "
                        "does not belong to your account."
                    ),
                    session.user,
                    session.csrf_token,
                ),
                HTTPStatus.NOT_FOUND,
            )

        # Returns the edit form.
        return Response(
            edit_item_page(
                session.user,
                session.csrf_token,
                item,
            )
        )

    # Reads the submitted edit form.
    form = read_form(environ)

    # Checks the form security token.
    if not valid_csrf(form, session):
        return Response(
            error_page(
                "Request blocked",
                "The security token was not valid.",
                session.user,
                session.csrf_token,
            ),
            HTTPStatus.FORBIDDEN,
        )

    # Reads the item ID.
    item_id = get_item_id(form)

    # Loads the item and checks ownership.
    item = inventory_service.get_item(
        item_id or 0,
        session.user.id,
    )

    # Displays an error when the item is missing.
    if item is None:
        return Response(
            error_page(
                "Item not found",
                (
                    "The item does not exist or "
                    "does not belong to your account."
                ),
                session.user,
                session.csrf_token,
            ),
            HTTPStatus.NOT_FOUND,
        )

    # Validates and updates the inventory item.
    errors = inventory_service.update_item(
        item.id,
        session.user.id,
        form,
    )

    # Displays update errors.
    if errors:
        return Response(
            edit_item_page(
                session.user,
                session.csrf_token,
                item,
                errors,
                form,
            ),
            HTTPStatus.BAD_REQUEST,
        )

    # Returns to the dashboard after success.
    return Response.redirect(
        message_url("Inventory item updated.")
    )


def handle_delete_item(environ: dict) -> Response:
    """Delete an inventory item."""

    # Requires an active session.
    session = require_session(environ)

    if isinstance(session, Response):
        return session

    # Reads the submitted deletion form.
    form = read_form(environ)

    # Checks the form security token.
    if not valid_csrf(form, session):
        return Response(
            error_page(
                "Request blocked",
                "The security token was not valid.",
                session.user,
                session.csrf_token,
            ),
            HTTPStatus.FORBIDDEN,
        )

    # Reads the item ID.
    item_id = get_item_id(form)

    # Deletes only an item owned by the user.
    if (
        item_id is None
        or not inventory_service.delete_item(
            item_id,
            session.user.id,
        )
    ):
        return Response.redirect(
            message_url(
                (
                    "The item was not found or "
                    "could not be deleted."
                ),
                "error",
            )
        )

    # Returns to the dashboard after success.
    return Response.redirect(
        message_url("Inventory item deleted.")
    )


def handle_static(path: str) -> Response:
    """Serve the application stylesheet."""

    # Allows only the approved stylesheet.
    if path != "/static/styles.css":
        return Response(
            "Not found",
            HTTPStatus.NOT_FOUND,
        )

    # Finds the stylesheet inside the static folder.
    css_path = (
        Path(__file__).resolve().parent
        / "static"
        / "styles.css"
    )

    # Returns the CSS file to the browser.
    return Response(
        css_path.read_bytes(),
        headers=[
            (
                "Content-Type",
                "text/css; charset=utf-8",
            )
        ],
    )


# Connects each URL and request method to a function.
ROUTES: dict[
    tuple[str, str],
    Callable[[dict], Response],
] = {
    ("GET", "/"): handle_index,

    ("GET", "/login"): handle_login,
    ("POST", "/login"): handle_login,

    ("GET", "/register"): handle_register,
    ("POST", "/register"): handle_register,

    ("POST", "/logout"): handle_logout,

    ("GET", "/dashboard"): handle_dashboard,

    ("POST", "/inventory/add"): handle_add_item,

    ("GET", "/inventory/edit"): handle_edit_item,
    ("POST", "/inventory/edit"): handle_edit_item,

    ("POST", "/inventory/delete"): handle_delete_item,
}


def application(
    environ: dict,
    start_response: Callable,
) -> list[bytes]:
    """Process one request and return a response."""

    # Reads the request method.
    method = environ.get(
        "REQUEST_METHOD",
        "GET",
    ).upper()

    # Reads the requested page path.
    path = urlparse(
        environ.get("PATH_INFO", "/")
    ).path

    try:
        # Sends stylesheet requests to the static handler.
        if (
            path.startswith("/static/")
            and method == "GET"
        ):
            response = handle_static(path)

        else:
            # Finds the function matching the request.
            handler = ROUTES.get(
                (method, path)
            )

            # Runs the route or displays a page not found error.
            if handler:
                response = handler(environ)
            else:
                response = Response(
                    error_page(
                        "Page not found",
                        (
                            "The requested page "
                            "does not exist."
                        ),
                    ),
                    HTTPStatus.NOT_FOUND,
                )

    except Exception as error:
        # Prints the technical error in the terminal.
        print(f"Application error: {error}")

        # Shows a safe message in the browser.
        response = Response(
            error_page(
                "Application error",
                (
                    "The request could not be completed. "
                    "Please try again."
                ),
            ),
            HTTPStatus.INTERNAL_SERVER_ERROR,
        )

    # Adds the response body size.
    headers = [
        (
            "Content-Length",
            str(len(response.body)),
        )
    ] + response.headers

    # Uses HTML when no other content type was supplied.
    if not any(
        name.lower() == "content-type"
        for name, _ in headers
    ):
        headers.append(
            (
                "Content-Type",
                "text/html; charset=utf-8",
            )
        )

    # Sends the status and headers to the server.
    start_response(
        (
            f"{response.status.value} "
            f"{response.status.phrase}"
        ),
        headers,
    )

    # Returns the response body.
    return [response.body]


def main() -> None:
    """Initialize the database and start the server."""

    # Creates missing database tables without deleting existing data.
    database.initialize()

    # Removes expired login sessions.
    database.delete_expired_sessions(
        __import__("security").utc_now()
    )

    # Displays the address used to open the application.
    print(
        f"AppInventory is running at "
        f"http://{config.HOST}:{config.PORT}"
    )

    # Starts the local web server.
    with make_server(
        config.HOST,
        config.PORT,
        application,
    ) as server:
        server.serve_forever()


# Runs the server when this file is opened directly.
if __name__ == "__main__":
    main()
