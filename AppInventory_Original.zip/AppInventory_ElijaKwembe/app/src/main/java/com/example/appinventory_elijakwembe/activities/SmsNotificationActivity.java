package com.example.appinventory_elijakwembe.activities;

import android.Manifest; // SMS permission constant
import android.content.Intent; // Used to move between screens
import android.content.pm.PackageManager; // Permission check result
import android.os.Bundle; // Activity state
import android.telephony.SmsManager; // Sends SMS
import android.util.Log; // Logcat logs
import android.widget.ImageButton; // Home logo button
import android.widget.TextView; // Status text
import android.widget.Toast; // Quick messages to user

import androidx.annotation.NonNull; // Null safety for callback
import androidx.appcompat.app.AppCompatActivity; // Base activity
import androidx.core.app.ActivityCompat; // Request permission
import androidx.core.content.ContextCompat; // Check permission

import com.example.appinventory_elijakwembe.R; // App resources
import com.google.android.material.button.MaterialButton; // Material button

public class SmsNotificationActivity extends AppCompatActivity {

    // Tag for Logcat
    private static final String TAG_SMS = "SMS_UI";

    // Permission request code
    private static final int REQUEST_SMS_PERMISSION = 100;

    // UI views
    private TextView textStatus;
    private MaterialButton buttonRequestSms;
    private MaterialButton buttonSendTestSms;
    private ImageButton buttonSmsHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notifications);

        Log.d(TAG_SMS, "SmsNotificationActivity opened");

        // Connect UI elements from XML
        textStatus = findViewById(R.id.textSmsStatus);
        buttonRequestSms = findViewById(R.id.buttonRequestSms);
        buttonSendTestSms = findViewById(R.id.buttonSendTestSms);
        buttonSmsHome = findViewById(R.id.buttonSmsHome);

        // Show the current permission status
        updatePermissionStatus();

        // Ask for SMS permission
        buttonRequestSms.setOnClickListener(v -> {
            Log.d(TAG_SMS, "Request permission clicked");
            checkAndRequestSmsPermission();
        });

        // Try sending a test SMS
        buttonSendTestSms.setOnClickListener(v -> {
            Log.d(TAG_SMS, "Send test SMS clicked");

            if (hasSmsPermission()) {
                sendTestSms();
            } else {
                Toast.makeText(this, "SMS permission is not granted", Toast.LENGTH_SHORT).show();
                updatePermissionStatus();
            }
        });

        // Home button returns to login screen
        buttonSmsHome.setOnClickListener(v -> {
            Log.d(TAG_SMS, "Home clicked");
            startActivity(new Intent(SmsNotificationActivity.this, LoginActivity.class));
            finish();
        });
    }

    // Check if SEND_SMS permission is granted
    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    // If not granted, request permission from the user
    private void checkAndRequestSmsPermission() {
        if (hasSmsPermission()) {
            Toast.makeText(this, "SMS permission is already granted", Toast.LENGTH_SHORT).show();
            updatePermissionStatus();
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    REQUEST_SMS_PERMISSION
            );
        }
    }

    // Android calls this after the user answers the permission popup
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_SMS_PERMISSION) {

            boolean granted = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;

            Log.d(TAG_SMS, "Permission result granted=" + granted);

            if (granted) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }

            updatePermissionStatus();
        }
    }

    // Update the status message depending on permission
    private void updatePermissionStatus() {
        if (hasSmsPermission()) {
            textStatus.setText("SMS permission is granted. The app can send alerts such as low inventory.");
        } else {
            textStatus.setText("SMS permission is not granted. The app will still work but will not send SMS alerts.");
        }
    }

    // Send a test SMS (usually works only on a real phone with SIM)
    private void sendTestSms() {
        try {
            String phoneNumber = "5551234567"; // Demo number
            String message = "Inventory alert from AppInventory. A low inventory item needs attention.";

            Log.d(TAG_SMS, "Attempting to send SMS to " + phoneNumber);

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            Toast.makeText(this, "Test SMS request sent (real device needed)", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Log.e(TAG_SMS, "SMS failed: " + e.getMessage());
            Toast.makeText(this, "Could not send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
