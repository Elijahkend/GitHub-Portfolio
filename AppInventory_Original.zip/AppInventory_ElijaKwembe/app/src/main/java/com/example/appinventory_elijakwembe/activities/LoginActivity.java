package com.example.appinventory_elijakwembe.activities;

import android.content.Intent; // Screen navigation
import android.content.SharedPreferences; // Remember me storage
import android.graphics.drawable.AnimationDrawable; // Animated background
import android.os.Bundle; // Activity state
import android.util.Log; // Logcat
import android.widget.TextView; // TextView
import android.widget.Toast; // Quick message

import androidx.appcompat.app.AppCompatActivity; // Base activity
import androidx.constraintlayout.widget.ConstraintLayout; // Layout container

import com.example.appinventory_elijakwembe.R; // Resources
import com.example.appinventory_elijakwembe.data.DatabaseHelper; // SQLite helper
import com.example.appinventory_elijakwembe.models.User; // User model
import com.google.android.material.button.MaterialButton; // Material button
import com.google.android.material.card.MaterialCardView; // Logo card
import com.google.android.material.checkbox.MaterialCheckBox; // Checkbox
import com.google.android.material.textfield.TextInputEditText; // Inputs

public class LoginActivity extends AppCompatActivity {

    // Log tag
    private static final String TAG_LOGIN = "LOGIN_UI";

    // SharedPreferences keys
    private static final String PREFS_NAME = "app_prefs";
    private static final String KEY_REMEMBER_ME = "remember_me";

    // Database helper
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d(TAG_LOGIN, "LoginActivity opened");

        // Init database helper
        db = new DatabaseHelper(this);

        // Start animated background
        ConstraintLayout rootLayout = findViewById(R.id.rootLayout);
        if (rootLayout.getBackground() instanceof AnimationDrawable) {
            AnimationDrawable animationDrawable = (AnimationDrawable) rootLayout.getBackground();
            animationDrawable.setEnterFadeDuration(2000);
            animationDrawable.setExitFadeDuration(2000);
            animationDrawable.start();
        }

        // Logo animation
        MaterialCardView logoCard = findViewById(R.id.logoCard);
        logoCard.setOnClickListener(v -> v.animate()
                .rotationY(10f)
                .scaleX(1.15f)
                .scaleY(1.15f)
                .setDuration(200)
                .withEndAction(() -> v.animate()
                        .rotationY(0f)
                        .scaleX(1.08f)
                        .scaleY(1.08f)
                        .setDuration(200))
                .start()
        );

        // Continuous logo pulse
        logoCard.animate()
                .setDuration(0)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        logoCard.animate()
                                .scaleX(1.08f)
                                .scaleY(1.08f)
                                .setDuration(1000)
                                .withEndAction(() -> logoCard.animate()
                                        .scaleX(1f)
                                        .scaleY(1f)
                                        .setDuration(800)
                                        .withEndAction(this))
                                .start();
                    }
                })
                .start();

        // Connect UI elements
        MaterialCheckBox rememberCheck = findViewById(R.id.checkRememberMe);
        TextView forgotPassword = findViewById(R.id.textForgotPassword);
        MaterialButton loginButton = findViewById(R.id.buttonLogin);
        MaterialButton createAccountButton = findViewById(R.id.buttonCreateAccount);
        TextInputEditText editUsernameOrEmail = findViewById(R.id.editTextUsername);
        TextInputEditText editPassword = findViewById(R.id.editTextPassword);

        // Load Remember Me state
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        rememberCheck.setChecked(prefs.getBoolean(KEY_REMEMBER_ME, false));

        // Save Remember Me state when toggled
        rememberCheck.setOnCheckedChangeListener((buttonView, isChecked) ->
                prefs.edit().putBoolean(KEY_REMEMBER_ME, isChecked).apply()
        );

        // Forgot password placeholder
        forgotPassword.setOnClickListener(v ->
                Toast.makeText(this, "Forgot password clicked", Toast.LENGTH_SHORT).show()
        );

        // Login button checks DB
        loginButton.setOnClickListener(v -> {

            String usernameOrEmail = (editUsernameOrEmail.getText() == null)
                    ? "" : editUsernameOrEmail.getText().toString().trim();

            String password = (editPassword.getText() == null)
                    ? "" : editPassword.getText().toString().trim();

            // Basic validation
            if (usernameOrEmail.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username or email and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validate login against SQLite (username OR email)
            boolean valid = db.loginValid(usernameOrEmail, password);

            Log.d(TAG_LOGIN, "Login attempt for=" + usernameOrEmail + " valid=" + valid);

            if (valid) {

                // Tie in User model by reading the user profile from DB
                User user = db.getUserByUsernameOrEmail(usernameOrEmail);

                if (user != null) {
                    Log.d(TAG_LOGIN, "User loaded: " + user.getFirstName() + " " + user.getLastName()
                            + " | dob=" + user.getDateOfBirth());
                } else {
                    Log.d(TAG_LOGIN, "User profile not found, but loginValid returned true");
                }

                // Go to inventory screen
                startActivity(new Intent(LoginActivity.this, InventoryActivity.class));
                finish();

            } else {
                Toast.makeText(this, "Login failed. Create an account first.", Toast.LENGTH_SHORT).show();
            }
        });

        // Create account opens RegisterActivity
        createAccountButton.setOnClickListener(v ->
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class))
        );
    }
}
