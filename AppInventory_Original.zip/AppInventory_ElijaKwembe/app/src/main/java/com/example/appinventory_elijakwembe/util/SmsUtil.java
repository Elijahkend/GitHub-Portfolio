package com.example.appinventory_elijakwembe.util;

import android.telephony.SmsManager;
import android.util.Log;

// Utility class used to send SMS messages
// This keeps SMS logic separate from Activities
public class SmsUtil {

    // Log tag for debugging SMS actions
    private static final String TAG_SMS = "SMS_UTIL";

    // Sends an SMS message to the given phone number
    // NOTE: This requires SEND_SMS permission
    public static void sendSms(String phoneNumber, String message) {

        try {
            Log.d(TAG_SMS, "Sending SMS to " + phoneNumber);

            // Get default SMS manager
            SmsManager smsManager = SmsManager.getDefault();

            // Send the text message
            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    message,
                    null,
                    null
            );

            Log.d(TAG_SMS, "SMS sent successfully");

        } catch (Exception e) {
            // Log any error so it appears in Logcat
            Log.e(TAG_SMS, "Failed to send SMS: " + e.getMessage());
        }
    }
}
