package com.example.appinventory_elijakwembe.adapters;

import android.util.Log; // Logcat
import android.view.LayoutInflater; // Inflate row layout
import android.view.View; // View
import android.view.ViewGroup; // Parent container
import android.widget.ImageButton; // Row buttons
import android.widget.TextView; // Row text

import androidx.annotation.NonNull; // Null safety
import androidx.recyclerview.widget.RecyclerView; // RecyclerView

import com.example.appinventory_elijakwembe.R; // Resources
import com.example.appinventory_elijakwembe.models.InventoryItem; // Model

import java.util.ArrayList; // List

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    // Log tag
    private static final String TAG_ADAPTER = "ADAPTER_UI";

    // Delete click listener
    public interface OnDeleteClickListener {
        void onDeleteClick(int position);
    }

    // Quantity change listener
    public interface OnQuantityChangeListener {
        void onIncrease(int position);
        void onDecrease(int position);
    }

    // Data list
    private final ArrayList<InventoryItem> items;

    // Callbacks
    private final OnDeleteClickListener deleteListener;
    private final OnQuantityChangeListener quantityListener;

    public InventoryAdapter(ArrayList<InventoryItem> items,
                            OnDeleteClickListener deleteListener,
                            OnQuantityChangeListener quantityListener) {
        this.items = items;
        this.deleteListener = deleteListener;
        this.quantityListener = quantityListener;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        // Inflate row layout
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_inventory_item, parent, false);

        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {

        // Get item for this row
        InventoryItem item = items.get(position);

        // Fill row text
        holder.textName.setText(item.getName());
        holder.textQty.setText(String.valueOf(item.getQuantity()));
        holder.textDate.setText(item.getDate());

        // Delete button
        if (holder.buttonDelete != null) {
            holder.buttonDelete.setOnClickListener(v -> {
                int pos = holder.getAdapterPosition();
                if (pos == RecyclerView.NO_POSITION) return;

                Log.d(TAG_ADAPTER, "Delete clicked pos=" + pos);
                if (deleteListener != null) deleteListener.onDeleteClick(pos);
            });
        }

        // Plus button
        if (holder.buttonPlus != null) {
            holder.buttonPlus.setOnClickListener(v -> {
                int pos = holder.getAdapterPosition();
                if (pos == RecyclerView.NO_POSITION) return;

                Log.d(TAG_ADAPTER, "Plus clicked pos=" + pos);
                if (quantityListener != null) quantityListener.onIncrease(pos);
            });
        }

        // Minus button
        if (holder.buttonMinus != null) {
            holder.buttonMinus.setOnClickListener(v -> {
                int pos = holder.getAdapterPosition();
                if (pos == RecyclerView.NO_POSITION) return;

                Log.d(TAG_ADAPTER, "Minus clicked pos=" + pos);
                if (quantityListener != null) quantityListener.onDecrease(pos);
            });
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class InventoryViewHolder extends RecyclerView.ViewHolder {

        // Row views
        TextView textName, textQty, textDate;
        ImageButton buttonDelete, buttonPlus, buttonMinus;

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);

            // Text fields
            textName = itemView.findViewById(R.id.textItemName);
            textQty = itemView.findViewById(R.id.textItemQty);
            textDate = itemView.findViewById(R.id.textItemDate);

            // Buttons (must exist in row_inventory_item.xml)
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
            buttonPlus = itemView.findViewById(R.id.buttonPlus);
            buttonMinus = itemView.findViewById(R.id.buttonMinus);
        }
    }
}
