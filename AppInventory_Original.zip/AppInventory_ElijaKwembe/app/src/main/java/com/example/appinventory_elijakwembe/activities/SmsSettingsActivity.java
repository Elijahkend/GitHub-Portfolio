package com.example.appinventory_elijakwembe.activities;

import android.content.Intent; // Move between screens
import android.os.Bundle; // Activity state
import android.util.Log; // Logcat
import android.widget.ImageButton; // Home or back button
import android.widget.Toast; // Quick message

import androidx.appcompat.app.AppCompatActivity; // Base activity

import com.example.appinventory_elijakwembe.R;

public class SmsSettingsActivity extends AppCompatActivity {

    // Log tag for this screen
    private static final String TAG_SMS_SETTINGS = "SMS_SETTINGS";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Load the SMS settings screen layout
        setContentView(R.layout.activity_sms_settings);

        Log.d(TAG_SMS_SETTINGS, "SmsSettingsActivity opened");

        // Optional: if your layout has a home or back button, connect it here
        // If you do not have this button yet, remove these lines for now
        ImageButton buttonHome = findViewById(R.id.buttonSmsSettingsHome);

        buttonHome.setOnClickListener(v -> {
            Log.d(TAG_SMS_SETTINGS, "Home clicked");
            Toast.makeText(this, "Returning to Home", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(SmsSettingsActivity.this, LoginActivity.class));
            finish();
        });
    }
}
