package com.example.appinventory_elijakwembe.activities;

import android.os.Bundle; // Activity state
import android.text.Editable; // TextWatcher value
import android.text.TextUtils; // Empty checks
import android.text.TextWatcher; // Auto format DOB
import android.util.Log; // Logcat
import android.widget.ImageButton; // Back button
import android.widget.Toast; // Messages

import androidx.appcompat.app.AppCompatActivity; // Base activity

import com.example.appinventory_elijakwembe.R; // Resources
import com.example.appinventory_elijakwembe.data.DatabaseHelper; // SQLite helper
import com.example.appinventory_elijakwembe.models.User; // User model
import com.google.android.material.button.MaterialButton; // Material button
import com.google.android.material.textfield.TextInputEditText; // Material input

import java.util.Calendar; // Age check

public class RegisterActivity extends AppCompatActivity {

    // Log tag
    private static final String TAG_REG = "REGISTER_UI";

    // Input fields
    private TextInputEditText editFirstName;
    private TextInputEditText editLastName;
    private TextInputEditText editUsername;
    private TextInputEditText editEmail;
    private TextInputEditText editDob;
    private TextInputEditText editPassword;
    private TextInputEditText editConfirmPassword;

    // Buttons
    private ImageButton buttonBack;
    private MaterialButton buttonCreate;

    // Database helper
    private DatabaseHelper db;

    // Prevent TextWatcher looping
    private boolean dobIsUpdating = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Log.d(TAG_REG, "RegisterActivity opened");

        // Connect UI
        buttonBack = findViewById(R.id.buttonBack);
        buttonCreate = findViewById(R.id.buttonCreateAccount);

        editFirstName = findViewById(R.id.editRegisterFirstName);
        editLastName = findViewById(R.id.editRegisterLastName);
        editUsername = findViewById(R.id.editRegisterUsername);
        editEmail = findViewById(R.id.editRegisterEmail);
        editDob = findViewById(R.id.editRegisterDob);
        editPassword = findViewById(R.id.editRegisterPassword);
        editConfirmPassword = findViewById(R.id.editRegisterConfirmPassword);

        // Init DB
        db = new DatabaseHelper(this);

        // Back to Login
        buttonBack.setOnClickListener(v -> finish());

        // Auto format DOB as DD/MM/YY
        editDob.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (dobIsUpdating) return;
                dobIsUpdating = true;

                // Keep digits only
                String digits = s.toString().replace("/", "");

                // Limit to 6 digits (DDMMYY)
                if (digits.length() > 6) digits = digits.substring(0, 6);

                StringBuilder formatted = new StringBuilder();

                // DD
                if (digits.length() >= 2) {
                    formatted.append(digits, 0, 2).append("/");
                } else {
                    formatted.append(digits);
                    setDobText(formatted.toString());
                    return;
                }

                // MM
                if (digits.length() >= 4) {
                    formatted.append(digits, 2, 4).append("/");
                } else {
                    formatted.append(digits.substring(2));
                    setDobText(formatted.toString());
                    return;
                }

                // YY
                if (digits.length() > 4) {
                    formatted.append(digits.substring(4));
                }

                setDobText(formatted.toString());
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });

        // Create account
        buttonCreate.setOnClickListener(v -> {

            String firstName = getTextValue(editFirstName);
            String lastName = getTextValue(editLastName);
            String username = getTextValue(editUsername);
            String email = getTextValue(editEmail); // optional, I included this just for visual sack as in real life, this is needed to reset password.
            String dob = getTextValue(editDob);
            String password = getTextValue(editPassword);
            String confirmPassword = getTextValue(editConfirmPassword);

            // Required field checks
            if (TextUtils.isEmpty(firstName) || TextUtils.isEmpty(lastName)
                    || TextUtils.isEmpty(username) || TextUtils.isEmpty(dob)
                    || TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword)) {
                Toast.makeText(this, "Please fill in all required fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Password match check
            if (!password.equals(confirmPassword)) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }

            // DOB format check
            if (!dob.matches("\\d{2}/\\d{2}/\\d{2}")) {
                Toast.makeText(this, "DOB must be in DD/MM/YY format", Toast.LENGTH_SHORT).show();
                return;
            }


            // Basic date validation (DD/MM)
            int day = Integer.parseInt(dob.substring(0, 2));
            int month = Integer.parseInt(dob.substring(3, 5));

            if (day < 1 || day > 31 || month < 1 || month > 12) {
                Toast.makeText(this, "Enter a valid date (DD/MM/YY)", Toast.LENGTH_SHORT).show();
                return;
            }

            // Minimum age check
            if (!isAtLeast18(dob)) {
                Toast.makeText(this, "You must be at least 18 years old to register", Toast.LENGTH_SHORT).show();
                return;
            }


            // Create a User model object (this ties your User class to the DB)
            User user = new User(firstName, lastName, username, email, dob);

            // Save user to SQLite using the User object
            boolean created = db.registerUser(user, password);

            Log.d(TAG_REG, "Register attempt created=" + created);

            if (created) {
                Toast.makeText(this, "Account created. Please log in.", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Username or email already exists. Try another.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Set DOB and move cursor to end
    private void setDobText(String value) {
        editDob.setText(value); // set formatted text
        int cursorPos = Math.min(value.length(), editDob.getText() == null ? 0 : editDob.getText().length()); // safe cursor
        editDob.setSelection(cursorPos); // move cursor
        dobIsUpdating = false; // unlock watcher
    }


    // Safe text read helper
    private String getTextValue(TextInputEditText field) {
        return (field.getText() == null) ? "" : field.getText().toString().trim();
    }

    // Age validation using DD/MM/YY


    private boolean isAtLeast18(String dob) {

        try {
            int day = Integer.parseInt(dob.substring(0, 2));// Day
            int month = Integer.parseInt(dob.substring(3, 5)); // month
            int yearTwoDigits = Integer.parseInt(dob.substring(6, 8));

            int currentYear = Calendar.getInstance().get(Calendar.YEAR);
            int currentTwoDigits = currentYear % 100;

            // Convert YY into full year
            int fullYear = (yearTwoDigits <= currentTwoDigits) ? (2000 + yearTwoDigits) : (1900 + yearTwoDigits);

            Calendar birthDate = Calendar.getInstance();
            birthDate.set(Calendar.YEAR, fullYear);
            birthDate.set(Calendar.MONTH, month - 1);
            birthDate.set(Calendar.DAY_OF_MONTH, day);
            birthDate.set(Calendar.HOUR_OF_DAY, 0);
            birthDate.set(Calendar.MINUTE, 0);
            birthDate.set(Calendar.SECOND, 0);
            birthDate.set(Calendar.MILLISECOND, 0);

            Calendar today = Calendar.getInstance();

            int age = today.get(Calendar.YEAR) - birthDate.get(Calendar.YEAR);

            Calendar birthdayThisYear = (Calendar) birthDate.clone();
            birthdayThisYear.set(Calendar.YEAR, today.get(Calendar.YEAR));
            if (today.before(birthdayThisYear)) age--;

            return age >= 18;

        } catch (Exception e) {
            Log.e(TAG_REG, "Age check failed: " + e.getMessage());
            return false;
        }
    }
}
