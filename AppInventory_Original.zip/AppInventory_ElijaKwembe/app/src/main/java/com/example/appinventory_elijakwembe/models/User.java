package com.example.appinventory_elijakwembe.models;

// Represents one app user that can be saved to SQLite
public class User {

    // Primary key from the database (only set after reading from DB)
    private long id;

    // User profile fields
    private String firstName;
    private String lastName;
    private String username;
    private String email;       // optional
    private String dateOfBirth; // expected format: DD/MM/YY

    // Constructor for creating a new user before saving to DB
    public User(String firstName, String lastName, String username, String email, String dateOfBirth) {
        this.id = -1; // -1 means "not saved yet"
        this.firstName = safeTrim(firstName);
        this.lastName = safeTrim(lastName);
        this.username = safeTrim(username);
        this.email = safeTrim(email);
        this.dateOfBirth = safeTrim(dateOfBirth);
    }

    // Constructor for loading a user that already exists in DB
    public User(long id, String firstName, String lastName, String username, String email, String dateOfBirth) {
        this.id = id; // real DB id
        this.firstName = safeTrim(firstName);
        this.lastName = safeTrim(lastName);
        this.username = safeTrim(username);
        this.email = safeTrim(email);
        this.dateOfBirth = safeTrim(dateOfBirth);
    }

    // Get database id
    public long getId() {
        return id;
    }

    // Get first name
    public String getFirstName() {
        return firstName;
    }

    // Get last name
    public String getLastName() {
        return lastName;
    }

    // Get username
    public String getUsername() {
        return username;
    }

    // Get email (can be empty)
    public String getEmail() {
        return email;
    }

    // Get DOB string
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    // Small helper to avoid null issues and remove extra spaces
    private String safeTrim(String value) {
        return (value == null) ? "" : value.trim();
    }
}
