package com.example.appinventory_elijakwembe.models;

// Model class that represents one inventory item
public class InventoryItem {

    // Primary key from SQLite
    private long id;

    // Item details
    private String name;
    private int quantity;
    private String date;

    // Constructor used when loading item from database
    public InventoryItem(long id, String name, int quantity, String date) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.date = date;
    }

    // Constructor used before item is saved to database
    public InventoryItem(String name, int quantity, String date) {
        this.id = -1; // temporary id until saved
        this.name = name;
        this.quantity = quantity;
        this.date = date;
    }

    // Get item id
    public long getId() {
        return id;
    }

    // Get item name
    public String getName() {
        return name;
    }

    // Get item quantity
    public int getQuantity() {
        return quantity;
    }

    // Update quantity locally if needed
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Get item date
    public String getDate() {
        return date;
    }
}
