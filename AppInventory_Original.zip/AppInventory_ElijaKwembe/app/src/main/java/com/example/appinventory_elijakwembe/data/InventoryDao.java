package com.example.appinventory_elijakwembe.data;

public class InventoryDao {
}
