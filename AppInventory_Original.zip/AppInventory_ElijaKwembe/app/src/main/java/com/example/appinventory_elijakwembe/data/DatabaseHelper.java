package com.example.appinventory_elijakwembe.data;

import android.content.ContentValues; // Used to insert and update rows
import android.content.Context; // Context for DB
import android.database.Cursor; // Read results
import android.database.sqlite.SQLiteDatabase; // Database object
import android.database.sqlite.SQLiteOpenHelper; // DB helper base class
import android.util.Log; // Logcat

import com.example.appinventory_elijakwembe.models.User; // User model

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name and version
    private static final String DB_NAME = "appinventory.db";
    private static final int DB_VERSION = 3;

    // Log tag
    private static final String TAG_DB = "DB_TEST";

    // Users table name and columns
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_FIRST_NAME = "first_name";
    public static final String COL_LAST_NAME = "last_name";
    public static final String COL_DOB = "dob";
    public static final String COL_USERNAME = "username";
    public static final String COL_EMAIL = "email";
    public static final String COL_PASSWORD = "password";

    // Inventory table name and columns
    public static final String TABLE_INVENTORY = "inventory";
    public static final String COL_ITEM_ID = "id";
    public static final String COL_ITEM_NAME = "name";
    public static final String COL_ITEM_QTY = "quantity";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create users table
        String createUsers =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_FIRST_NAME + " TEXT NOT NULL, " +
                        COL_LAST_NAME + " TEXT NOT NULL, " +
                        COL_DOB + " TEXT NOT NULL, " +
                        COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                        COL_EMAIL + " TEXT UNIQUE, " +
                        COL_PASSWORD + " TEXT NOT NULL" +
                        ");";

        // Create inventory table
        String createInventory =
                "CREATE TABLE " + TABLE_INVENTORY + " (" +
                        COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_ITEM_NAME + " TEXT NOT NULL, " +
                        COL_ITEM_QTY + " INTEGER NOT NULL" +
                        ");";

        db.execSQL(createUsers);
        db.execSQL(createInventory);

        Log.d(TAG_DB, "Database created successfully");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // Simple class project upgrade: recreate tables
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);

        Log.d(TAG_DB, "Database upgraded old=" + oldVersion + " new=" + newVersion);
    }

    // CREATE: Register user using a User object
    public boolean registerUser(User user, String password) {

        Log.d(TAG_DB, "registerUser(User) called");

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_FIRST_NAME, user.getFirstName());
        values.put(COL_LAST_NAME, user.getLastName());
        values.put(COL_DOB, user.getDateOfBirth());
        values.put(COL_USERNAME, user.getUsername());
        values.put(COL_PASSWORD, password);

        // Store email only if user typed one
        if (user.getEmail() != null && !user.getEmail().trim().isEmpty()) {
            values.put(COL_EMAIL, user.getEmail().trim());
        }

        long result = db.insert(TABLE_USERS, null, values);

        Log.d(TAG_DB, "registerUser(User) result=" + result);

        return result != -1;
    }

    // READ: Login using username OR email + password
    public boolean loginValid(String usernameOrEmail, String password) {

        Log.d(TAG_DB, "loginValid() called for=" + usernameOrEmail);

        SQLiteDatabase db = getReadableDatabase();

        String selection =
                "(" + COL_USERNAME + "=? OR " + COL_EMAIL + "=?) AND " + COL_PASSWORD + "=?";

        String[] selectionArgs = { usernameOrEmail, usernameOrEmail, password };

        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_USERS, null, selection, selectionArgs, null, null, null);
            boolean exists = (cursor != null) && cursor.moveToFirst();
            Log.d(TAG_DB, "loginValid result=" + exists);
            return exists;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    // READ: Get full user profile using username or email
    public User getUserByUsernameOrEmail(String usernameOrEmail) {

        SQLiteDatabase db = getReadableDatabase();

        String selection = COL_USERNAME + "=? OR " + COL_EMAIL + "=?";
        String[] selectionArgs = { usernameOrEmail, usernameOrEmail };

        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_USERS, null, selection, selectionArgs, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_USER_ID));
                String firstName = cursor.getString(cursor.getColumnIndexOrThrow(COL_FIRST_NAME));
                String lastName = cursor.getString(cursor.getColumnIndexOrThrow(COL_LAST_NAME));
                String dob = cursor.getString(cursor.getColumnIndexOrThrow(COL_DOB));
                String username = cursor.getString(cursor.getColumnIndexOrThrow(COL_USERNAME));

                String email = cursor.isNull(cursor.getColumnIndexOrThrow(COL_EMAIL))
                        ? "" : cursor.getString(cursor.getColumnIndexOrThrow(COL_EMAIL));

                return new User(id, firstName, lastName, username, email, dob);
            }

            return null;

        } finally {
            if (cursor != null) cursor.close();
        }
    }

    // Inventory CREATE
    public long addInventoryItem(String name, int quantity) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_QTY, quantity);

        return db.insert(TABLE_INVENTORY, null, values);
    }

    // Inventory READ
    public Cursor getAllInventoryItems() {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(TABLE_INVENTORY, null, null, null, null, null, COL_ITEM_NAME + " ASC");
    }

    // Inventory UPDATE
    public boolean updateInventoryQuantity(long id, int newQuantity) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_ITEM_QTY, newQuantity);

        int rows = db.update(TABLE_INVENTORY, values, COL_ITEM_ID + "=?", new String[]{ String.valueOf(id) });
        return rows > 0;
    }

    // Inventory DELETE
    public boolean deleteInventoryItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(TABLE_INVENTORY, COL_ITEM_ID + "=?", new String[]{ String.valueOf(id) });
        return rows > 0;
    }
}
