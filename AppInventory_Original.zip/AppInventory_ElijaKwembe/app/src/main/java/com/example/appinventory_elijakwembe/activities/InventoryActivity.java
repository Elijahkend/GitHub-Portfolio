package com.example.appinventory_elijakwembe.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.appinventory_elijakwembe.R;
import com.example.appinventory_elijakwembe.adapters.InventoryAdapter;
import com.example.appinventory_elijakwembe.data.DatabaseHelper;
import com.example.appinventory_elijakwembe.models.InventoryItem;
import com.google.android.material.button.MaterialButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class InventoryActivity extends AppCompatActivity {

    // Log tag for this screen
    private static final String TAG_UI = "UI";

    // Data list for RecyclerView
    private final ArrayList<InventoryItem> inventoryList = new ArrayList<>();

    // Adapter
    private InventoryAdapter adapter;

    // Database helper
    private DatabaseHelper db;

    // Views (match activity_inventory.xml ids)
    private ConstraintLayout inventoryRoot;
    private ImageButton buttonHome;
    private RecyclerView recyclerInventory;
    private MaterialButton buttonAddItem;
    private MaterialButton buttonSmsNotifications;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        Log.d(TAG_UI, "InventoryActivity opened");

        // Init DB
        db = new DatabaseHelper(this);

        // Connect views by id (these MUST match XML)
        inventoryRoot = findViewById(R.id.inventoryRoot);
        buttonHome = findViewById(R.id.buttonHome);
        recyclerInventory = findViewById(R.id.recyclerInventory);
        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonSmsNotifications = findViewById(R.id.buttonSmsNotifications);

        // Start animated background
        if (inventoryRoot.getBackground() instanceof AnimationDrawable) {
            AnimationDrawable anim = (AnimationDrawable) inventoryRoot.getBackground();
            anim.setEnterFadeDuration(2000);
            anim.setExitFadeDuration(2000);
            anim.start();
        }

        // Home button to Login screen
        buttonHome.setOnClickListener(v -> {
            Log.d(TAG_UI, "Home clicked");
            startActivity(new Intent(InventoryActivity.this, LoginActivity.class));
            finish();
        });

        // Setup RecyclerView
        recyclerInventory.setLayoutManager(new LinearLayoutManager(this));

        // Create adapter with listeners
        adapter = new InventoryAdapter(
                inventoryList,
                this::onDeleteItem,
                new InventoryAdapter.OnQuantityChangeListener() {
                    @Override
                    public void onIncrease(int position) {
                        onIncreaseQty(position);
                    }

                    @Override
                    public void onDecrease(int position) {
                        onDecreaseQty(position);
                    }
                }
        );

        recyclerInventory.setAdapter(adapter);

        // Load items from DB
        loadInventoryFromDb();

        // Add Item button
        buttonAddItem.setOnClickListener(v -> {
            Log.d(TAG_UI, "Add Item clicked");
            showAddItemDialog();
        });

        // SMS Alerts screen button
        buttonSmsNotifications.setOnClickListener(v -> {
            Log.d(TAG_UI, "SMS Alerts clicked");
            startActivity(new Intent(InventoryActivity.this, SmsNotificationActivity.class));
        });
    }

    // READ: Load inventory from SQLite
    private void loadInventoryFromDb() {
        Log.d(TAG_UI, "Loading inventory from DB");

        inventoryList.clear();

        Cursor cursor = null;
        try {
            cursor = db.getAllInventoryItems();

            if (cursor != null) {
                int idIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_ID);
                int nameIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_NAME);
                int qtyIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_QTY);

                while (cursor.moveToNext()) {
                    long id = (idIndex != -1) ? cursor.getLong(idIndex) : -1;
                    String name = (nameIndex != -1) ? cursor.getString(nameIndex) : "";
                    int qty = (qtyIndex != -1) ? cursor.getInt(qtyIndex) : 0;

                    // Date is display only
                    inventoryList.add(new InventoryItem(id, name, qty, today()));
                }
            }
        } catch (Exception e) {
            Log.e(TAG_UI, "Error loading inventory: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
        }

        adapter.notifyDataSetChanged();
        Log.d(TAG_UI, "Inventory loaded count=" + inventoryList.size());
    }

    // CREATE: Insert new item into DB then reload
    private void showAddItemDialog() {

        View dialogView = LayoutInflater.from(this)
                .inflate(R.layout.dialog_add_item, null, false);

        EditText editName = dialogView.findViewById(R.id.editItemName);
        EditText editQty = dialogView.findViewById(R.id.editItemQty);

        new AlertDialog.Builder(this)
                .setTitle("Add inventory item")
                .setView(dialogView)
                .setPositiveButton("Add", (dialog, which) -> {

                    String name = editName.getText().toString().trim();
                    String qtyText = editQty.getText().toString().trim();

                    if (name.isEmpty() || qtyText.isEmpty()) {
                        Toast.makeText(this, "Please enter name and quantity", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int qty;
                    try {
                        qty = Integer.parseInt(qtyText);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    long newId = db.addInventoryItem(name, qty);

                    if (newId == -1) {
                        Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Log.d(TAG_UI, "Inserted item id=" + newId);

                    loadInventoryFromDb();
                    Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // UPDATE: Increase quantity
    private void onIncreaseQty(int position) {
        if (position < 0 || position >= inventoryList.size()) return;

        InventoryItem item = inventoryList.get(position);
        int newQty = item.getQuantity() + 1;

        Log.d(TAG_UI, "Increase qty id=" + item.getId() + " to " + newQty);

        boolean updated = db.updateInventoryQuantity(item.getId(), newQty);

        if (updated) {
            loadInventoryFromDb();
        } else {
            Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
        }
    }

    // UPDATE: Decrease quantity
    private void onDecreaseQty(int position) {
        if (position < 0 || position >= inventoryList.size()) return;

        InventoryItem item = inventoryList.get(position);
        int newQty = item.getQuantity() - 1;
        if (newQty < 0) newQty = 0;

        Log.d(TAG_UI, "Decrease qty id=" + item.getId() + " to " + newQty);

        boolean updated = db.updateInventoryQuantity(item.getId(), newQty);

        if (updated) {
            loadInventoryFromDb();
        } else {
            Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
        }
    }

    // DELETE: Delete item
    private void onDeleteItem(int position) {
        if (position < 0 || position >= inventoryList.size()) return;

        InventoryItem item = inventoryList.get(position);

        Log.d(TAG_UI, "Delete item id=" + item.getId());

        boolean deleted = db.deleteInventoryItem(item.getId());

        if (deleted) {
            loadInventoryFromDb();
        } else {
            Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
        }
    }

    // Display date helper
    private String today() {
        return new SimpleDateFormat("dd/MM/yy", Locale.getDefault()).format(new Date());
    }
}
