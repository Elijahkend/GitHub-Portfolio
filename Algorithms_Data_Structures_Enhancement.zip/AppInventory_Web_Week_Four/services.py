"""
AppInventory Web Enhancement
Author: Elija Kwembe
Date: July 09, 2026
Course: CS 499 Computer Science Capstone
Purpose: Keep authentication and inventory business rules separate from routes,
         including normalized search, ranked results, and pagination.
"""

# Imports SQLite errors used when account information already exists.
import sqlite3

# Imports dataclass to create simple session objects.
from dataclasses import dataclass

# Provides type hints for dictionaries and optional results.
from typing import Dict, Optional

# Imports the number of hours a login session remains active.
from config import INVENTORY_PAGE_SIZE, SESSION_HOURS

# Imports the database access layer.
from database import Database

# Imports the user and inventory data models.
from models import (
    InventoryItem,
    InventorySearchPage,
    InventorySummary,
    User,
)

# Imports password, token, and time security functions.
from security import (
    hash_password,
    new_csrf_token,
    new_session_token,
    session_expiration,
    utc_now,
    verify_password,
)

# Imports validation functions for forms.
from validators import (
    validate_inventory_item,
    validate_login,
    validate_registration,
)


# Creates a session object whose values cannot be changed.
@dataclass(frozen=True)
class SessionData:
    """Stores information needed for a signed in user session."""

    # Secure token used to identify the login session.
    token: str

    # Security token used to protect form submissions.
    csrf_token: str

    # User connected to the login session.
    user: User


class AuthService:
    """Handles account registration, login, logout, and sessions."""

    def __init__(self, database: Database):
        # Stores the database object used by this service.
        self.database = database

    def register(
        self,
        form: Dict[str, str],
    ) -> tuple[Optional[int], list[str]]:
        """Validate the form and create a user account."""

        # Checks the submitted registration information.
        data, errors = validate_registration(form)

        # Stops registration when validation errors exist.
        if errors:
            return None, errors

        try:
            # Creates the new user with a securely hashed password.
            user_id = self.database.create_user(
                first_name=str(data["first_name"]),
                last_name=str(data["last_name"]),
                username=str(data["username"]),
                email=str(data["email"]),
                date_of_birth=str(data["date_of_birth"]),
                password_hash=hash_password(
                    str(data["password"])
                ),
                created_at=utc_now(),
            )

            # Returns the new user ID when registration succeeds.
            return user_id, []

        except sqlite3.IntegrityError:
            # Returns an error when the username or email already exists.
            return None, [
                "That username or email is already registered."
            ]

    def login(
        self,
        form: Dict[str, str],
    ) -> tuple[Optional[SessionData], list[str]]:
        """Validate login information and create a session."""

        # Checks the submitted login information.
        data, errors = validate_login(form)

        # Stops login when validation errors exist.
        if errors:
            return None, errors

        # Finds the account using either the username or email.
        row = self.database.find_user_by_identity(
            str(data["identity"])
        )

        # Checks whether the account and password are valid.
        if (
            row is None
            or not verify_password(
                str(data["password"]),
                row["password_hash"],
            )
        ):
            return None, [
                "The username, email, or password is incorrect."
            ]

        # Creates a secure token for the login session.
        token = new_session_token()

        # Creates a secure token for protected forms.
        csrf_token = new_csrf_token()

        # Stores the new session in the database.
        self.database.create_session(
            token=token,
            user_id=int(row["id"]),
            csrf_token=csrf_token,
            created_at=utc_now(),
            expires_at=session_expiration(SESSION_HOURS),
        )

        # Converts the database result into a User object.
        user = User(
            id=int(row["id"]),
            first_name=row["first_name"],
            last_name=row["last_name"],
            username=row["username"],
            email=row["email"],
            date_of_birth=row["date_of_birth"],
        )

        # Returns the completed session information.
        return SessionData(
            token=token,
            csrf_token=csrf_token,
            user=user,
        ), []

    def get_session(
        self,
        token: str | None,
    ) -> Optional[SessionData]:
        """Return an active session when the token is valid."""

        # Returns nothing when no session token was provided.
        if not token:
            return None

        # Searches for a session that has not expired.
        row = self.database.get_session(
            token,
            utc_now(),
        )

        # Returns nothing when the session is missing or expired.
        if row is None:
            return None

        # Creates the User object connected to the session.
        user = User(
            id=int(row["user_id"]),
            first_name=row["first_name"],
            last_name=row["last_name"],
            username=row["username"],
            email=row["email"],
            date_of_birth=row["date_of_birth"],
        )

        # Returns the active session information.
        return SessionData(
            token=row["token"],
            csrf_token=row["csrf_token"],
            user=user,
        )

    def logout(
        self,
        token: str | None,
    ) -> None:
        """Delete the current login session."""

        # Deletes the session only when a token exists.
        if token:
            self.database.delete_session(token)


class InventoryService:
    """Handles inventory rules outside the web routes."""

    def __init__(self, database: Database):
        # Stores the database object used by this service.
        self.database = database

    def list_items(
        self,
        user_id: int,
    ) -> list[InventoryItem]:
        """Return all inventory items owned by one user."""

        # Requests the user's inventory records from the database.
        return self.database.list_inventory(user_id)

    @staticmethod
    def normalize_search_query(query: str) -> str:
        """Remove unnecessary spacing and limit the search text."""

        # Collapsing repeated spaces produces a consistent search value.
        return " ".join(query.split())[:80]

    def search_items(
        self,
        user_id: int,
        query: str = "",
        page: int = 1,
        page_size: int = INVENTORY_PAGE_SIZE,
    ) -> InventorySearchPage:
        """Return ranked user owned inventory results in bounded pages."""

        normalized_query = self.normalize_search_query(query)

        # Prevents invalid or excessively large page requests.
        safe_page_size = min(max(page_size, 1), 100)
        requested_page = max(page, 1)

        # Counting first allows the page number to be corrected safely.
        total_matches = self.database.count_inventory_matches(
            user_id,
            normalized_query,
        )

        # At least one page is retained so the interface can display page 1
        # even when the search produces no matching records.
        total_pages = max(
            1,
            (total_matches + safe_page_size - 1) // safe_page_size,
        )
        safe_page = min(requested_page, total_pages)
        offset = (safe_page - 1) * safe_page_size

        # Only the records needed for the current page are transferred.
        items = tuple(
            self.database.search_inventory(
                user_id=user_id,
                search_term=normalized_query,
                limit=safe_page_size,
                offset=offset,
            )
        )

        return InventorySearchPage(
            items=items,
            query=normalized_query,
            page=safe_page,
            page_size=safe_page_size,
            total_matches=total_matches,
            total_pages=total_pages,
        )

    def get_summary(
        self,
        user_id: int,
    ) -> InventorySummary:
        """Return totals for every inventory item owned by the user."""

        return self.database.inventory_summary(user_id)

    def get_item(
        self,
        item_id: int,
        user_id: int,
    ) -> Optional[InventoryItem]:
        """Return one inventory item owned by the user."""

        # Checks both the item ID and the user ID.
        return self.database.get_inventory_item(
            item_id,
            user_id,
        )

    def add_item(
        self,
        user_id: int,
        form: Dict[str, str],
    ) -> list[str]:
        """Validate and add a new inventory item."""

        # Checks the submitted inventory information.
        data, errors = validate_inventory_item(form)

        # Stops the operation when validation errors exist.
        if errors:
            return errors

        # Saves the new inventory item in the database.
        self.database.add_inventory_item(
            user_id=user_id,
            name=str(data["name"]),
            quantity=int(data["quantity"]),
            low_stock_threshold=int(
                data["low_stock_threshold"]
            ),
            created_at=utc_now(),
        )

        # Returns an empty list when the item is added successfully.
        return []

    def update_item(
        self,
        item_id: int,
        user_id: int,
        form: Dict[str, str],
    ) -> list[str]:
        """Validate and update an inventory item."""

        # Checks the submitted inventory information.
        data, errors = validate_inventory_item(form)

        # Stops the update when validation errors exist.
        if errors:
            return errors

        # Updates the item only when it belongs to the user.
        updated = self.database.update_inventory_item(
            item_id=item_id,
            user_id=user_id,
            name=str(data["name"]),
            quantity=int(data["quantity"]),
            low_stock_threshold=int(
                data["low_stock_threshold"]
            ),
            updated_at=utc_now(),
        )

        # Returns an error when the item is missing or unauthorized.
        if not updated:
            return [
                (
                    "The inventory item was not found or "
                    "you do not have access to it."
                )
            ]

        # Returns an empty list when the update succeeds.
        return []

    def delete_item(
        self,
        item_id: int,
        user_id: int,
    ) -> bool:
        """Delete an inventory item owned by the user."""

        # Deletes the item only when the item and owner IDs match.
        return self.database.delete_inventory_item(
            item_id,
            user_id,
        )