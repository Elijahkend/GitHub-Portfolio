-- AppInventory Web Enhancement
-- Author: Elija Kwembe
-- Date: July 08, 2026
-- Course: CS 499 Computer Science Capstone
-- Purpose: Define secure tables and indexes used by ranked inventory search.

-- Enables SQLite foreign key enforcement.
PRAGMA foreign_keys = ON;

-- Stores registered user account information.
CREATE TABLE IF NOT EXISTS users (
    -- Unique identifier automatically assigned to each user.
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Stores the user's first and last names.
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,

    -- Username must be unique and is not case sensitive.
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,

    -- Email must also be unique and is not case sensitive.
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,

    -- Stores the user's date of birth.
    date_of_birth TEXT NOT NULL,

    -- Stores the protected password hash instead of the plain password.
    password_hash TEXT NOT NULL,

    -- Automatically records when the account was created.
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Stores inventory items belonging to registered users.
CREATE TABLE IF NOT EXISTS inventory_items (
    -- Unique identifier automatically assigned to each inventory item.
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Connects the inventory item to the user who owns it.
    user_id INTEGER NOT NULL,

    -- Stores the inventory item name.
    name TEXT NOT NULL,

    -- Prevents an inventory quantity from being less than zero.
    quantity INTEGER NOT NULL CHECK (quantity >= 0),

    -- Sets the default low stock warning level to five.
    low_stock_threshold INTEGER NOT NULL DEFAULT 5
        CHECK (low_stock_threshold >= 0),

    -- Records when the inventory item was created.
    created_at TEXT NOT NULL,

    -- Records when the inventory item was last updated.
    updated_at TEXT NOT NULL,

    -- Deletes the user's inventory items when the user account is deleted.
    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);

-- Stores authenticated user sessions.
CREATE TABLE IF NOT EXISTS sessions (
    -- Unique session token used to identify the signed in user.
    token TEXT PRIMARY KEY,

    -- Connects the session to the registered user.
    user_id INTEGER NOT NULL,

    -- Protects forms against cross site request forgery attacks.
    csrf_token TEXT NOT NULL,

    -- Records when the session was created.
    created_at TEXT NOT NULL,

    -- Records when the session will expire.
    expires_at TEXT NOT NULL,

    -- Deletes the session when the related user account is deleted.
    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);

-- Improves searches for inventory items belonging to a specific user.
CREATE INDEX IF NOT EXISTS idx_inventory_user
ON inventory_items(user_id);

-- Supports ownership filtering and ordered item name retrieval.
-- The leading wildcard used for contains searching still has O(n) worst case
-- time within one user's records, but this composite index improves the user
-- filter and alphabetical ordering used by default and prefix based searches.
CREATE INDEX IF NOT EXISTS idx_inventory_user_name
ON inventory_items(user_id, name COLLATE NOCASE);

-- Improves searches for expired user sessions.
CREATE INDEX IF NOT EXISTS idx_sessions_expiration
ON sessions(expires_at);