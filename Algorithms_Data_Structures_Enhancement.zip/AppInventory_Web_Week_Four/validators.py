"""
AppInventory Web Enhancement
Author: Elija Kwembe
Date: July 09 2026
Course: CS 499 Computer Science Capstone
Purpose: Validate and normalize user input before it reaches the database.
"""

# Provides pattern matching for usernames and email addresses.
import re

# Provides date tools for checking a user's date of birth.
from datetime import date

# Provides type hints for dictionaries and returned values.
from typing import Dict, Tuple


# Allows usernames with letters, numbers, and underscores.
# The username must contain between 4 and 24 characters.
USERNAME_PATTERN = re.compile(r"^[A-Za-z0-9_]{4,24}$")

# Checks that an email contains a name, an at symbol, and a domain.
EMAIL_PATTERN = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def clean(value: str | None) -> str:
    """Remove extra spaces and safely handle missing values."""

    # Uses an empty string when no value is provided.
    return (value or "").strip()


def validate_registration(
    data: Dict[str, str],
) -> Tuple[Dict[str, str], list[str]]:
    """Validate and prepare registration information."""

    # Cleans and organizes all submitted registration values.
    normalized = {
        "first_name": clean(data.get("first_name")),
        "last_name": clean(data.get("last_name")),
        "username": clean(data.get("username")),
        "email": clean(data.get("email")).lower(),
        "date_of_birth": clean(data.get("date_of_birth")),
        "password": data.get("password", ""),
        "confirm_password": data.get("confirm_password", ""),
    }

    # Stores any validation messages found during the checks.
    errors: list[str] = []

    # Requires at least two characters in the first name.
    if len(normalized["first_name"]) < 2:
        errors.append(
            "First name must contain at least 2 characters."
        )

    # Requires at least two characters in the last name.
    if len(normalized["last_name"]) < 2:
        errors.append(
            "Last name must contain at least 2 characters."
        )

    # Checks the username length and allowed characters.
    if not USERNAME_PATTERN.fullmatch(
        normalized["username"]
    ):
        errors.append(
            "Username must be 4 to 24 characters and use only "
            "letters, numbers, or underscores."
        )

    # Checks that the email address uses a valid format.
    if not EMAIL_PATTERN.fullmatch(
        normalized["email"]
    ):
        errors.append(
            "Enter a valid email address."
        )

    try:
        # Converts the submitted birth date into a date object.
        birth_date = date.fromisoformat(
            normalized["date_of_birth"]
        )

        # Prevents today or a future date from being used.
        if birth_date >= date.today():
            errors.append(
                "Date of birth must be earlier than today."
            )

    except ValueError:
        # Adds an error when the date cannot be understood.
        errors.append(
            "Enter a valid date of birth."
        )

    # Gets the submitted password for security checks.
    password = normalized["password"]

    # Requires the password to contain at least eight characters.
    if len(password) < 8:
        errors.append(
            "Password must contain at least 8 characters."
        )

    # Requires at least one uppercase letter.
    if not any(
        character.isupper()
        for character in password
    ):
        errors.append(
            "Password must contain at least one uppercase letter."
        )

    # Requires at least one lowercase letter.
    if not any(
        character.islower()
        for character in password
    ):
        errors.append(
            "Password must contain at least one lowercase letter."
        )

    # Requires at least one number.
    if not any(
        character.isdigit()
        for character in password
    ):
        errors.append(
            "Password must contain at least one number."
        )

    # Confirms that both password fields match.
    if password != normalized["confirm_password"]:
        errors.append(
            "The passwords do not match."
        )

    # Returns the cleaned values and any validation errors.
    return normalized, errors


def validate_login(
    data: Dict[str, str],
) -> Tuple[Dict[str, str], list[str]]:
    """Validate login information."""

    # Cleans the username or email but keeps the password unchanged.
    normalized = {
        "identity": clean(data.get("identity")),
        "password": data.get("password", ""),
    }

    # Stores login validation messages.
    errors: list[str] = []

    # Requires both the identity and password fields.
    if (
        not normalized["identity"]
        or not normalized["password"]
    ):
        errors.append(
            "Enter your username or email and password."
        )

    # Returns the prepared login values and any errors.
    return normalized, errors


def validate_inventory_item(
    data: Dict[str, str],
) -> Tuple[Dict[str, object], list[str]]:
    """Validate and prepare inventory item information."""

    # Sets the default values before checking the submitted form.
    normalized: Dict[str, object] = {
        "name": clean(data.get("name")),
        "quantity": 0,
        "low_stock_threshold": 0,
    }

    # Stores inventory validation messages.
    errors: list[str] = []

    # Requires an item name between 2 and 80 characters.
    if (
        len(str(normalized["name"])) < 2
        or len(str(normalized["name"])) > 80
    ):
        errors.append(
            "Item name must contain 2 to 80 characters."
        )

    try:
        # Converts the submitted quantity into a whole number.
        quantity = int(
            clean(data.get("quantity"))
        )

        # Accepts quantities only within the allowed range.
        if quantity < 0 or quantity > 999_999:
            raise ValueError

        # Stores the checked quantity.
        normalized["quantity"] = quantity

    except ValueError:
        # Adds an error when the quantity is invalid.
        errors.append(
            "Quantity must be a whole number from 0 to 999999."
        )

    try:
        # Converts the low stock level into a whole number.
        threshold = int(
            clean(data.get("low_stock_threshold"))
        )

        # Accepts low stock levels only within the allowed range.
        if threshold < 0 or threshold > 999_999:
            raise ValueError

        # Stores the checked low stock level.
        normalized["low_stock_threshold"] = threshold

    except ValueError:
        # Adds an error when the low stock level is invalid.
        errors.append(
            "Low stock level must be a whole number from 0 to 999999."
        )

    # Returns the prepared inventory values and any errors.
    return normalized, errors
