"""
AppInventory Web Enhancement
Author: Elija Kwembe
Date: July 06, 2026
Course: CS 499 Computer Science Capstone
Purpose: Define data models shared by the application layers, including
         structured search and pagination results.
"""

# Imports dataclass to create simple data objects.
from dataclasses import dataclass


# Makes the User object easy to create and prevents its values from changing.
@dataclass(frozen=True)
class User:
    """Stores information for one registered user."""

    # Unique ID assigned to the user.
    id: int

    # User's first name.
    first_name: str

    # User's last name.
    last_name: str

    # Username used to sign in.
    username: str

    # Email connected to the account.
    email: str

    # User's date of birth.
    date_of_birth: str


# Makes the InventoryItem object easy to create and prevents its values from changing.
@dataclass(frozen=True)
class InventoryItem:
    """Stores information for one inventory item."""

    # Unique ID assigned to the item.
    id: int

    # ID of the user who owns the item.
    user_id: int

    # Name of the inventory item.
    name: str

    # Current number of items available.
    quantity: int

    # Quantity that triggers a low stock warning.
    low_stock_threshold: int

    # Date and time when the item was created.
    created_at: str

    # Date and time when the item was last updated.
    updated_at: str

    @property
    def stock_status(self) -> str:
        """Return the current stock level message."""

        # Returns out of stock when no items are available.
        if self.quantity == 0:
            return "Out of stock"

        # Returns low stock when the quantity reaches the warning level.
        if self.quantity <= self.low_stock_threshold:
            return "Low stock"

        # Returns in stock when the quantity is above the warning level.
        return "In stock"

# Stores dashboard totals without loading every inventory record into Python.
@dataclass(frozen=True)
class InventorySummary:
    """Stores summary values for all inventory owned by one user."""

    # Total number of inventory records.
    record_count: int

    # Combined quantity from all inventory records.
    total_units: int

    # Number of records at or below their low stock level.
    low_stock: int

    # Number of records with no available stock.
    out_of_stock: int


# Groups the search result list with its pagination information.
@dataclass(frozen=True)
class InventorySearchPage:
    """Stores one page of ranked inventory search results."""

    # Immutable collection of items returned for the current page.
    items: tuple[InventoryItem, ...]

    # Normalized search text entered by the user.
    query: str

    # Current page number.
    page: int

    # Maximum number of records shown on one page.
    page_size: int

    # Total records matching the search text.
    total_matches: int

    # Total number of result pages.
    total_pages: int

    @property
    def first_result_number(self) -> int:
        """Return the visible number of the first result."""

        if not self.items:
            return 0

        return ((self.page - 1) * self.page_size) + 1

    @property
    def last_result_number(self) -> int:
        """Return the visible number of the last result."""

        if not self.items:
            return 0

        return self.first_result_number + len(self.items) - 1

    @property
    def has_previous(self) -> bool:
        """Return whether an earlier result page exists."""

        return self.page > 1

    @property
    def has_next(self) -> bool:
        """Return whether another result page exists."""

        return self.page < self.total_pages
