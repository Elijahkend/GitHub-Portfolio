"""
AppInventory Web Enhancement
Author: Elija Kwembe
Date: July 06, 2026
Course: CS 499 Computer Science Capstone
Purpose: Store application settings in one location.
"""

# Imports Path so the application can build reliable file locations.
from pathlib import Path


# Finds the folder containing this configuration file.
# This allows the application to locate related files correctly.
BASE_DIR = Path(__file__).resolve().parent


# Defines the full location of the SQLite database file.
# The database will be stored inside the main application folder.
DATABASE_PATH = BASE_DIR / "app_inventory.db"


# Defines the local network address used to run the web application.
# The value 127.0.0.1 means the application is available only on this computer.
HOST = "127.0.0.1"


# Defines the port number used to open the application in a web browser.
# The application can be reached at http://127.0.0.1:8000.
PORT = 8000


# Defines how many hours a user login session remains active.
# After eight hours, the session expires and the user must sign in again.
SESSION_HOURS = 8

# Limits each inventory result page to ten records.
# Bounded pages keep the browser responsive when the database contains
# hundreds or thousands of inventory items.
INVENTORY_PAGE_SIZE = 10
