# AppInventory Algorithms and Data Structures Enhancement

This project is the CS 499 Algorithms and Data Structures enhancement. It builds on the completed browser based inventory application by adding database side search, relevance ranking, structured pagination, and efficient dashboard summaries.

## Algorithms and data structures improvement

The inventory screen now contains one search bar in the upper right area of the inventory table. A user can enter all or part of an item name. The application normalizes the query, protects SQL wildcard characters, searches only records owned by the signed in user, ranks exact matches before beginning matches and other partial matches, and returns ten records at a time.

`InventorySearchPage` is an immutable data structure that groups the result items with the normalized query, page size, current page, total matches, and total pages. `InventorySummary` stores the four dashboard totals without requiring the application to load every inventory row into Python.

## Efficiency and Big O explanation

A partial contains search uses a leading wildcard. Therefore, the worst case search time is O(n) for the signed in user's inventory records because SQLite may need to inspect each owned item name. Sorting matching records is O(m log m), where m is the number of matches. Pagination limits the amount of result data transferred and displayed to O(k), where k is the page size of ten records. The composite user and name index helps ownership filtering, default ordering, and prefix based searching, but it does not remove the O(n) worst case created by a leading wildcard.

This design is more scalable than sending thousands of rows to the browser and filtering them there. A future version could use SQLite FTS5 or a dedicated search engine when the inventory grows beyond the needs of this project.

## Main features

1. Case insensitive partial inventory search
2. Exact, beginning, and contains match ranking
3. Literal handling of percent and underscore characters
4. User ownership filtering in every search query
5. Ten record result pages with previous and next controls
6. SQL aggregate dashboard totals
7. Parameterized SQLite statements
8. Existing password hashing, sessions, CSRF protection, validation, and ownership checks
9. Unit tests for search behavior, ranking, pagination, summaries, and security rules

## Run the application

The application uses only the Python standard library.

1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Run `python app.py`.
4. Open `http://127.0.0.1:8000` in a browser.

The database file is created automatically during the first run.

## Run the tests

Run `python -m unittest discover -s tests -v` from this folder.

## Project structure

`app.py` reads the search query and requested page from the URL.

`services.py` normalizes search text, calculates page boundaries, and creates the structured result page.

`database.py` performs ranked parameterized queries, matching counts, and summary aggregation.

`models.py` defines inventory, search page, summary, and user data structures.

`templates.py` creates the search bar, result messages, table, and pagination controls.

`schema.sql` defines tables and indexes.

`static/styles.css` positions the search bar and supports responsive pagination.

`tests/test_services.py` verifies the new algorithm and existing application rules.
