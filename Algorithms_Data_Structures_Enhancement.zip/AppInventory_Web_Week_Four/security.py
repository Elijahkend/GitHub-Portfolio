"""
AppInventory Web Enhancement
Author: Elija Kwembe
Date: July 09, 2026
Course: CS 499 Computer Science Capstone
Purpose: Protect passwords, sessions, and state changing forms.
"""

# Provides secure password hashing functions.
import hashlib

# Provides a safe way to compare password hashes.
import hmac

# Creates secure random values for salts and tokens.
import secrets

# Provides date and time tools for session expiration.
from datetime import datetime, timedelta, timezone


# Sets the number of times the password hashing process repeats.
# More repetitions make password guessing more difficult.
PBKDF2_ITERATIONS = 310_000


def hash_password(password: str) -> str:
    """Create a secure hash from a password."""

    # Creates a different random salt for every password.
    salt = secrets.token_bytes(16)

    # Combines the password and salt using PBKDF2.
    password_hash = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        PBKDF2_ITERATIONS,
    )

    # Stores the method, repetitions, salt, and hash in one string.
    return (
        f"pbkdf2_sha256$"
        f"{PBKDF2_ITERATIONS}$"
        f"{salt.hex()}$"
        f"{password_hash.hex()}"
    )


def verify_password(password: str, stored_value: str) -> bool:
    """Check whether a password matches the stored hash."""

    try:
        # Separates the stored password information into four parts.
        algorithm, iterations_text, salt_hex, expected_hex = (
            stored_value.split("$", 3)
        )

        # Rejects hashes created with an unexpected method.
        if algorithm != "pbkdf2_sha256":
            return False

        # Converts the stored repetition count into a number.
        iterations = int(iterations_text)

        # Hashes the entered password using the stored salt.
        actual = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            bytes.fromhex(salt_hex),
            iterations,
        )

        # Safely compares the new hash with the stored hash.
        return hmac.compare_digest(
            actual.hex(),
            expected_hex,
        )

    except (ValueError, TypeError):
        # Returns false when the stored password information is invalid.
        return False


def new_session_token() -> str:
    """Create a secure token for a login session."""

    # Generates a random token that identifies the signed in user.
    return secrets.token_urlsafe(32)


def new_csrf_token() -> str:
    """Create a secure token for protected forms."""

    # Generates a random token that helps block unauthorized form requests.
    return secrets.token_urlsafe(24)


def session_expiration(hours: int) -> str:
    """Create the time when a login session will expire."""

    # Adds the allowed session hours to the current UTC time.
    expires = datetime.now(timezone.utc) + timedelta(hours=hours)

    # Returns the expiration time as text for database storage.
    return expires.isoformat()


def utc_now() -> str:
    """Return the current UTC date and time."""

    # Returns the current UTC time as text.
    return datetime.now(timezone.utc).isoformat()