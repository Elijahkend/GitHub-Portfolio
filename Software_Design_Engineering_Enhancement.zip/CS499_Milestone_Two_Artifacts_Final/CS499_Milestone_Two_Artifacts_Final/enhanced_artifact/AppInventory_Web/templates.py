"""
AppInventory Web Enhancement
Author: Elija Kwembe
Date: July 10, 2026
Course: CS 499 Computer Science Capstone
Purpose: Build consistent and escaped HTML pages for the web interface.
"""

# Escapes user entered text before placing it inside HTML.
from html import escape

# Imports the user and inventory data models.
from models import InventoryItem, User


def _errors(errors: list[str]) -> str:
    """Create an HTML error message from a list of errors."""

    # Returns no HTML when there are no errors.
    if not errors:
        return ""

    # Creates one safe HTML list item for each error.
    items = "".join(
        f"<li>{escape(error)}</li>"
        for error in errors
    )

    # Places all errors inside a visible alert box.
    return (
        f'<div class="alert error" role="alert">'
        f"<ul>{items}</ul>"
        f"</div>"
    )


def _notice(message: str, kind: str = "success") -> str:
    """Create a success or error notice."""

    # Returns no HTML when there is no message.
    if not message:
        return ""

    # Allows only the supported message styles.
    safe_kind = "error" if kind == "error" else "success"

    # Escapes the message before showing it on the page.
    return (
        f'<div class="alert {safe_kind}" role="status">'
        f"{escape(message)}"
        f"</div>"
    )


def layout(
    title: str,
    body: str,
    user: User | None = None,
    csrf_token: str = "",
) -> str:
    """Wrap page content in one consistent responsive layout."""

    # Uses the dashboard layout when a signed in user is provided.
    if user:
        return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">

  <!-- Makes the page adjust correctly on phones and tablets. -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Displays the page name in the browser tab. -->
  <title>{escape(title)} | AppInventory</title>

  <!-- Loads the application stylesheet. -->
  <link rel="stylesheet" href="/static/styles.css">
</head>
<body>

  <!-- Creates the animated background design. -->
  <div class="page_glow glow_one"></div>
  <div class="page_glow glow_two"></div>
  <div class="page_glow glow_three"></div>
  <div class="page_grid"></div>

  <!-- Holds the sidebar and main dashboard content. -->
  <div class="app_shell">

    <!-- Displays account information and dashboard navigation. -->
    <aside class="app_sidebar glass_panel">

      <div class="sidebar_brand_wrap">
        <a class="brand" href="/dashboard">
          <span class="brand_mark"></span>
          AppInventory
        </a>
        <p class="sidebar_caption">Blue tech inventory workspace</p>
      </div>

      <!-- Displays the signed in user's name and username. -->
      <div class="profile_panel">
        <div class="profile_orb"></div>
        <div>
          <strong>
            {escape(user.first_name)} {escape(user.last_name)}
          </strong>
          <p>@{escape(user.username)}</p>
        </div>
      </div>

      <!-- Provides navigation to dashboard sections. -->
      <nav class="sidebar_nav">
        <a class="sidebar_link active" href="/dashboard">
          <span class="sidebar_icon"></span>
          <span>Dashboard</span>
        </a>

        <a class="sidebar_link" href="#add_item_card">
          <span class="sidebar_icon"></span>
          <span>Add Item</span>
        </a>

        <a class="sidebar_link" href="#inventory_table">
          <span class="sidebar_icon"></span>
          <span>Inventory</span>
        </a>
      </nav>

      <!-- Shows a short description of the dashboard. -->
      <div class="sidebar_card pulse_panel">
        <p class="eyebrow">Workspace</p>
        <h3>Smart stock control</h3>
        <p>
          Track low stock levels, update items, and manage records
          in one modern dashboard.
        </p>
      </div>

      <!-- Sends a protected logout request. -->
      <form method="post" action="/logout" class="sidebar_logout">
        <input
          type="hidden"
          name="csrf_token"
          value="{escape(csrf_token)}"
        >
        <button
          class="button secondary small full_width"
          type="submit"
        >
          Log out
        </button>
      </form>
    </aside>

    <!-- Holds the main dashboard area. -->
    <section class="app_main">

      <!-- Displays the current page title and navigation tabs. -->
      <header class="app_topbar glass_panel">
        <div>
          <p class="eyebrow">Cyber dashboard</p>
          <h2>{escape(title)}</h2>
        </div>

        <div class="user_actions">
          <div class="chip">Secure session active</div>

          <div class="section_tabs compact_tabs">
            <a class="section_tab active" href="/dashboard">
              Overview
            </a>
            <a class="section_tab" href="#inventory_table">
              Records
            </a>
            <a class="section_tab" href="#add_item_card">
              Add item
            </a>
          </div>
        </div>
      </header>

      <!-- Inserts the requested page content. -->
      <main class="page">{body}</main>
    </section>
  </div>

  <footer>
    CS 499 Software Design and Engineering Enhancement
  </footer>
</body>
</html>"""

    # Creates the navigation used on login and registration pages.
    navigation = """
    <nav class="topbar glass_bar">
      <a class="brand" href="/">
        <span class="brand_mark"></span>
        AppInventory
      </a>

      <div class="nav_tabs auth_switch">
        <a class="nav_tab active" href="/login">Sign in</a>
        <a class="nav_tab" href="/register">Register</a>
      </div>
    </nav>
    """

    # Returns the public layout for users who are not signed in.
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">

  <!-- Makes the page responsive on different screen sizes. -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>{escape(title)} | AppInventory</title>
  <link rel="stylesheet" href="/static/styles.css">
</head>
<body>

  <!-- Creates the animated background design. -->
  <div class="page_glow glow_one"></div>
  <div class="page_glow glow_two"></div>
  <div class="page_glow glow_three"></div>
  <div class="page_grid"></div>

  {navigation}

  <!-- Inserts the login, registration, or error page content. -->
  <main class="page">{body}</main>

  <footer>
    CS 499 Software Design and Engineering Enhancement
  </footer>
</body>
</html>"""

def login_page(
    errors: list[str] | None = None,
    message: str = "",
) -> str:
    """Create the login page."""

    # Builds the login page content.
    body = f"""
    <section class="auth_shell">

      <!-- Introduces the application and its security features. -->
      <div class="auth_intro hero_panel glass_panel">
        <p class="eyebrow">
          "Company Name" inventory platform
        </p>

        <h1>Your number one stop for all your inventories.</h1>

        <p>
          This enhanced version adds secure accounts, user specific
          inventory, and low stock alerts with a stronger modern design.
        </p>

        <!-- Displays important application options. -->
        <div class="hero_points">
          <span class="chip">Clickable image tab</span>
          <span class="chip">Customer Support</span>
          <span class="chip">Latest updates</span>
        </div>

        <!-- Displays short descriptions of application features. -->
        <div class="floating_stats">
          <div class="mini_card float_up">
            <strong>Live visual alerts</strong>
            <span>
              Low stock and out of stock records stand out quickly.
            </span>
          </div>

          <div class="mini_card float_down">
            <strong>Protected access</strong>
            <span>
              Hashed passwords, secure sessions, and form protection
              keep data safe.
            </span>
          </div>
        </div>
      </div>

      <!-- Displays the login form. -->
      <div class="card auth_card glass_panel">

        <div class="section_tabs">
          <a class="section_tab active" href="/login">
            Sign in
          </a>
          <a class="section_tab" href="/register">
            Create account
          </a>
        </div>

        <h2>Welcome back</h2>

        <p class="muted">
          Use your username or email to open your inventory dashboard.
        </p>

        <!-- Displays an account creation or logout message. -->
        {_notice(message)}

        <!-- Displays login validation errors. -->
        {_errors(errors or [])}

        <!-- Sends the login information to the server. -->
        <form method="post" action="/login" class="form_stack">

          <label>
            Username or email
            <input
              name="identity"
              type="text"
              autocomplete="username"
              required
              maxlength="120"
              placeholder="Enter your username or email"
            >
          </label>

          <label>
            Password
            <input
              name="password"
              type="password"
              autocomplete="current-password"
              required
              maxlength="128"
              placeholder="Enter your password"
            >
          </label>

          <button
            class="button primary glow_button"
            type="submit"
          >
            Sign in
          </button>
        </form>

        <p class="form_note">
          Need an account?
          <a href="/register">Create one</a>
        </p>
      </div>
    </section>
    """

    # Places the login content inside the public page layout.
    return layout("Sign in", body)


def register_page(
    errors: list[str] | None = None,
    values: dict[str, str] | None = None,
) -> str:
    """Create the account registration page."""

    # Uses an empty dictionary when no previous form values exist.
    values = values or {}

    # Safely returns a previous form value.
    value = lambda key: escape(
        values.get(key, ""),
        quote=True,
    )

    # Builds the registration page content.
    body = f"""
    <section class="auth_shell">

      <!-- Explains how user information is protected. -->
      <div class="auth_intro hero_panel glass_panel">
        <p class="eyebrow">Protected account setup</p>

        <h1>Create your workspace and keep inventory private.</h1>

        <p>
          Each user has separate records. Passwords are stored as
          salted hashes, and every request checks ownership before
          data is shown or changed.
        </p>

        <div class="hero_points">
          <span class="chip">User ownership checks</span>
          <span class="chip">Validation on every form</span>
          <span class="chip">SQL safe queries</span>
        </div>
      </div>

      <!-- Displays the account registration form. -->
      <div class="card auth_card wide glass_panel">

        <div class="section_tabs">
          <a class="section_tab" href="/login">
            Sign in
          </a>
          <a class="section_tab active" href="/register">
            Create account
          </a>
        </div>

        <h2>Create account</h2>

        <!-- Displays registration validation errors. -->
        {_errors(errors or [])}

        <!-- Sends the new account information to the server. -->
        <form method="post" action="/register" class="form_grid">

          <label>
            First name
            <input
              name="first_name"
              value="{value('first_name')}"
              required
              maxlength="50"
              placeholder="First name"
            >
          </label>

          <label>
            Last name
            <input
              name="last_name"
              value="{value('last_name')}"
              required
              maxlength="50"
              placeholder="Last name"
            >
          </label>

          <label>
            Username
            <input
              name="username"
              value="{value('username')}"
              required
              maxlength="24"
              placeholder="Choose a username"
            >
          </label>

          <label>
            Email
            <input
              name="email"
              type="email"
              value="{value('email')}"
              required
              maxlength="120"
              placeholder="you@example.com"
            >
          </label>

          <label>
            Date of birth
            <input
              name="date_of_birth"
              type="date"
              value="{value('date_of_birth')}"
              required
            >
          </label>

          <label>
            Password
            <input
              name="password"
              type="password"
              required
              maxlength="128"
              placeholder="Create a password"
            >
          </label>

          <label>
            Confirm password
            <input
              name="confirm_password"
              type="password"
              required
              maxlength="128"
              placeholder="Confirm your password"
            >
          </label>

          <div class="form_full">
            <button
              class="button primary glow_button"
              type="submit"
            >
              Create account
            </button>
          </div>
        </form>

        <p class="form_note">
          Already registered?
          <a href="/login">Sign in</a>
        </p>
      </div>
    </section>
    """

    # Places the registration content inside the public page layout.
    return layout("Create account", body)

def dashboard_page(
    user: User,
    csrf_token: str,
    items: list[InventoryItem],
    errors: list[str] | None = None,
    message: str = "",
    kind: str = "success",
    form_values: dict[str, str] | None = None,
) -> str:
    """Create the inventory dashboard page."""

    # Keeps submitted values when the add item form has an error.
    form_values = form_values or {}

    # Calculates the combined quantity of all inventory items.
    total_units = sum(
        item.quantity
        for item in items
    )

    # Counts items that have reached their low stock level.
    low_stock = sum(
        1
        for item in items
        if 0 < item.quantity <= item.low_stock_threshold
    )

    # Counts items with no available quantity.
    out_of_stock = sum(
        1
        for item in items
        if item.quantity == 0
    )

    # Stores one HTML table row for each inventory item.
    rows = []

    for item in items:
        # Uses the normal status style by default.
        status_class = "ok"

        # Uses the danger style when the item has no stock.
        if item.quantity == 0:
            status_class = "danger"

        # Uses the warning style when the item is low in stock.
        elif item.quantity <= item.low_stock_threshold:
            status_class = "warning"

        # Creates a table row for the current inventory item.
        rows.append(f"""
        <tr>
          <td>
            <strong>{escape(item.name)}</strong>
          </td>

          <td>{item.quantity}</td>

          <td>{item.low_stock_threshold}</td>

          <td>
            <span class="status {status_class}">
              {escape(item.stock_status)}
            </span>
          </td>

          <td class="actions">

            <!-- Opens the edit page for this inventory item. -->
            <a
              class="button secondary small"
              href="/inventory/edit?id={item.id}"
            >
              Edit
            </a>

            <!-- Sends a protected request to delete the item. -->
            <form
              method="post"
              action="/inventory/delete"
              onsubmit="return confirm('Delete this item?');"
            >
              <input
                type="hidden"
                name="csrf_token"
                value="{escape(csrf_token)}"
              >

              <input
                type="hidden"
                name="item_id"
                value="{item.id}"
              >

              <button
                class="button danger small"
                type="submit"
              >
                Delete
              </button>
            </form>
          </td>
        </tr>
        """)

    # Displays inventory rows or an empty inventory message.
    table_body = (
        "".join(rows)
        if rows
        else """
        <tr>
          <td colspan="5" class="empty">
            No inventory items yet. Add the first item using the form.
          </td>
        </tr>
        """
    )

    # Builds the dashboard page content.
    body = f"""
    <header class="page_header dashboard_header glass_panel">

      <!-- Displays the dashboard title and current username. -->
      <div>
        <p class="eyebrow">Inventory dashboard</p>
        <h1>Your inventory workspace</h1>
        <p class="muted">
          Signed in as {escape(user.username)}. Track stock,
          monitor low items, and manage records in one place.
        </p>
      </div>

      <!-- Displays important dashboard features. -->
      <div class="hero_points stats_chips">
        <span class="chip">Secure account</span>
        <span class="chip">Realtime status</span>
        <span class="chip">User specific records</span>
      </div>
    </header>

    <!-- Displays a successful or unsuccessful action message. -->
    {_notice(message, kind)}

    <!-- Displays inventory totals and status counts. -->
    <section class="metrics">

      <article class="metric glass_panel">
        <span>Items</span>
        <strong>{len(items)}</strong>
        <small>Records in your account</small>
      </article>

      <article class="metric glass_panel">
        <span>Total units</span>
        <strong>{total_units}</strong>
        <small>Combined stock quantity</small>
      </article>

      <article class="metric glass_panel">
        <span>Low stock</span>
        <strong>{low_stock}</strong>
        <small>Needs attention soon</small>
      </article>

      <article class="metric glass_panel">
        <span>Out of stock</span>
        <strong>{out_of_stock}</strong>
        <small>Currently unavailable</small>
      </article>
    </section>

    <!-- Places the add item form beside the inventory table. -->
    <section class="content_grid">

      <!-- Displays the form used to create an inventory item. -->
      <article
        class="card glass_panel lift_panel"
        id="add_item_card"
      >
        <div class="section_heading">
          <div>
            <p class="eyebrow">Quick action</p>
            <h2>Add inventory item</h2>
          </div>
        </div>

        <!-- Displays item validation errors. -->
        {_errors(errors or [])}

        <!-- Sends the new inventory item to the server. -->
        <form
          method="post"
          action="/inventory/add"
          class="form_stack"
        >
          <input
            type="hidden"
            name="csrf_token"
            value="{escape(csrf_token)}"
          >

          <label>
            Item name
            <input
              name="name"
              value="{escape(form_values.get('name', ''), quote=True)}"
              required
              maxlength="80"
              placeholder="Example: Wireless Mouse"
            >
          </label>

          <label>
            Quantity
            <input
              name="quantity"
              type="number"
              min="0"
              max="999999"
              value="{escape(form_values.get('quantity', '0'), quote=True)}"
              required
            >
          </label>

          <label>
            Low stock level
            <input
              name="low_stock_threshold"
              type="number"
              min="0"
              max="999999"
              value="{escape(form_values.get('low_stock_threshold', '5'), quote=True)}"
              required
            >
          </label>

          <button
            class="button primary glow_button"
            type="submit"
          >
            Add item
          </button>
        </form>
      </article>

      <!-- Displays inventory items owned by the current user. -->
      <article
        class="card table_card glass_panel"
        id="inventory_table"
      >
        <div class="section_heading">
          <div>
            <p class="eyebrow">Live records</p>
            <h2>Inventory records</h2>
            <p class="muted">
              Only records connected to your account are shown.
            </p>
          </div>
        </div>

        <div class="table_wrap">
          <table>

            <!-- Identifies each inventory table column. -->
            <thead>
              <tr>
                <th>Item</th>
                <th>Quantity</th>
                <th>Low level</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>

            <!-- Inserts all created inventory rows. -->
            <tbody>{table_body}</tbody>
          </table>
        </div>
      </article>
    </section>
    """

    # Places the dashboard inside the signed in layout.
    return layout(
        "Dashboard",
        body,
        user,
        csrf_token,
    )

def edit_item_page(
    user: User,
    csrf_token: str,
    item: InventoryItem,
    errors: list[str] | None = None,
    values: dict[str, str] | None = None,
) -> str:
    """Create the inventory edit page."""

    # Uses the current item information when no form values exist.
    values = values or {
        "name": item.name,
        "quantity": str(item.quantity),
        "low_stock_threshold": str(item.low_stock_threshold),
    }

    # Builds the inventory edit page content.
    body = f"""
    <section class="narrow">

      <!-- Returns the user to the main dashboard. -->
      <a class="back_link" href="/dashboard">
        Return to dashboard
      </a>

      <article class="card glass_panel lift_panel">
        <p class="eyebrow">Update inventory</p>

        <h1>Edit item</h1>

        <p class="muted">
          Update the selected inventory record and save your changes.
        </p>

        <!-- Displays validation errors from the update form. -->
        {_errors(errors or [])}

        <!-- Sends updated inventory information to the server. -->
        <form
          method="post"
          action="/inventory/edit"
          class="form_stack"
        >
          <input
            type="hidden"
            name="csrf_token"
            value="{escape(csrf_token)}"
          >

          <!-- Identifies the item being updated. -->
          <input
            type="hidden"
            name="item_id"
            value="{item.id}"
          >

          <label>
            Item name
            <input
              name="name"
              value="{escape(values.get('name', ''), quote=True)}"
              required
              maxlength="80"
            >
          </label>

          <label>
            Quantity
            <input
              name="quantity"
              type="number"
              min="0"
              max="999999"
              value="{escape(values.get('quantity', '0'), quote=True)}"
              required
            >
          </label>

          <label>
            Low stock level
            <input
              name="low_stock_threshold"
              type="number"
              min="0"
              max="999999"
              value="{escape(values.get('low_stock_threshold', '5'), quote=True)}"
              required
            >
          </label>

          <button
            class="button primary glow_button"
            type="submit"
          >
            Save changes
          </button>
        </form>
      </article>
    </section>
    """

    # Places the edit form inside the signed in layout.
    return layout(
        "Edit item",
        body,
        user,
        csrf_token,
    )


def error_page(
    title: str,
    message: str,
    user: User | None = None,
    csrf_token: str = "",
) -> str:
    """Create a safe application error page."""

    # Escapes the title and message before displaying them.
    body = f"""
    <section class="narrow">
      <article class="card glass_panel center">

        <h1>{escape(title)}</h1>

        <p>{escape(message)}</p>

        <!-- Returns the user to the correct page. -->
        <a
          class="button primary glow_button"
          href="{'/dashboard' if user else '/login'}"
        >
          Continue
        </a>
      </article>
    </section>
    """

    # Uses the dashboard layout when a user is signed in.
    return layout(
        title,
        body,
        user,
        csrf_token,
    )


