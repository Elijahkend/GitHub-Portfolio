"""
AppInventory Web Enhancement
Author: Elija Kwembe
Date: July 08, 2026
Course: CS 499 Computer Science Capstone
Purpose: Test authentication, validation, and inventory ownership rules.
"""

import sqlite3
import tempfile
import unittest
from pathlib import Path

from database import Database
from services import AuthService, InventoryService


class AppInventoryServiceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_directory = tempfile.TemporaryDirectory()
        self.database = Database(Path(self.temp_directory.name) / "test.db")
        self.database.initialize()
        self.auth = AuthService(self.database)
        self.inventory = InventoryService(self.database)

    def tearDown(self) -> None:
        self.temp_directory.cleanup()

    def registration_form(self, username: str, email: str) -> dict[str, str]:
        return {
            "first_name": "Alex",
            "last_name": "Carter",
            "username": username,
            "email": email,
            "date_of_birth": "1990-01-01",
            "password": "StrongPass1",
            "confirm_password": "StrongPass1",
        }

    def test_registration_hashes_password_and_login_works(self) -> None:
        user_id, errors = self.auth.register(self.registration_form("alex1", "alex@example.com"))
        self.assertIsNotNone(user_id)
        self.assertEqual([], errors)

        with self.database.connect() as connection:
            row = connection.execute("SELECT password_hash FROM users WHERE id = ?", (user_id,)).fetchone()
        self.assertNotEqual("StrongPass1", row["password_hash"])

        session, login_errors = self.auth.login({"identity": "alex1", "password": "StrongPass1"})
        self.assertIsNotNone(session)
        self.assertEqual([], login_errors)

    def test_duplicate_account_is_rejected(self) -> None:
        self.auth.register(self.registration_form("alex1", "alex@example.com"))
        user_id, errors = self.auth.register(self.registration_form("alex1", "other@example.com"))
        self.assertIsNone(user_id)
        self.assertTrue(errors)

    def test_inventory_is_separated_by_user(self) -> None:
        first_id, _ = self.auth.register(self.registration_form("alex1", "alex@example.com"))
        second_id, _ = self.auth.register(self.registration_form("student2", "student2@example.com"))
        self.inventory.add_item(first_id, {"name": "Laptop", "quantity": "4", "low_stock_threshold": "2"})

        self.assertEqual(1, len(self.inventory.list_items(first_id)))
        self.assertEqual(0, len(self.inventory.list_items(second_id)))

        item = self.inventory.list_items(first_id)[0]
        self.assertFalse(self.inventory.delete_item(item.id, second_id))
        self.assertEqual(1, len(self.inventory.list_items(first_id)))

    def test_negative_quantity_is_rejected(self) -> None:
        user_id, _ = self.auth.register(self.registration_form("alex1", "alex@example.com"))
        errors = self.inventory.add_item(user_id, {"name": "Laptop", "quantity": "-1", "low_stock_threshold": "2"})
        self.assertTrue(errors)
        self.assertEqual([], self.inventory.list_items(user_id))


if __name__ == "__main__":
    unittest.main()
