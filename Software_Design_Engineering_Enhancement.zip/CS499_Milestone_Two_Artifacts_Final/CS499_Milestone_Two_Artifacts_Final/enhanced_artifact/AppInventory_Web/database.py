"""
AppInventory Web Enhancement
Author: Elija Kwembe
Date: July 09, 2026
Course: CS 499 Computer Science Capstone
Purpose: Separate parameterized SQLite operations from the web interface.
"""

# Imports SQLite so the application can store and retrieve data.
import sqlite3

# Allows the database connection to be used safely with a with statement.
from contextlib import contextmanager

# Helps create reliable file paths.
from pathlib import Path

# Provides type hints for database connections and optional results.
from typing import Iterator, Optional

# Imports the application data models.
from models import InventoryItem, User


class Database:
    """Handles all database operations for the application."""

    def __init__(self, database_path: Path | str):
        # Stores the database file location as text.
        self.database_path = str(database_path)

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        """Open and safely close a database connection."""

        # Opens a connection to the SQLite database.
        connection = sqlite3.connect(self.database_path)

        # Allows database columns to be accessed by name.
        connection.row_factory = sqlite3.Row

        # Enables foreign key rules in SQLite.
        connection.execute("PRAGMA foreign_keys = ON")

        try:
            # Gives the connection to the database method using it.
            yield connection

            # Saves all successful database changes.
            connection.commit()

        except Exception:
            # Cancels changes when an error occurs.
            connection.rollback()

            # Sends the error back to the application.
            raise

        finally:
            # Always closes the database connection.
            connection.close()

    def initialize(self) -> None:
        """Create database tables without removing existing data."""

        # Finds the schema file stored beside this Python file.
        schema_path = Path(__file__).resolve().parent / "schema.sql"

        # Opens the database and runs the table creation script.
        with self.connect() as connection:
            connection.executescript(
                schema_path.read_text(encoding="utf-8")
            )

    def create_user(
        self,
        first_name: str,
        last_name: str,
        username: str,
        email: str,
        date_of_birth: str,
        password_hash: str,
        created_at: str,
    ) -> int:
        """Create a user and return the new user ID."""

        with self.connect() as connection:
            # Uses placeholders to safely insert account information.
            cursor = connection.execute(
                """
                INSERT INTO users
                    (
                        first_name,
                        last_name,
                        username,
                        email,
                        date_of_birth,
                        password_hash,
                        created_at
                    )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    first_name,
                    last_name,
                    username,
                    email,
                    date_of_birth,
                    password_hash,
                    created_at,
                ),
            )

            # Returns the ID created for the new user.
            return int(cursor.lastrowid)

    def find_user_by_identity(
        self,
        identity: str,
    ) -> Optional[sqlite3.Row]:
        """Find a user by username or email."""

        with self.connect() as connection:
            # Searches without treating uppercase and lowercase as different.
            return connection.execute(
                """
                SELECT *
                FROM users
                WHERE username = ? COLLATE NOCASE
                   OR email = ? COLLATE NOCASE
                """,
                (identity, identity),
            ).fetchone()

    def get_user(self, user_id: int) -> Optional[User]:
        """Return a user without including the password hash."""

        with self.connect() as connection:
            # Retrieves only the user information needed by the application.
            row = connection.execute(
                """
                SELECT
                    id,
                    first_name,
                    last_name,
                    username,
                    email,
                    date_of_birth
                FROM users
                WHERE id = ?
                """,
                (user_id,),
            ).fetchone()

        # Returns nothing when the user does not exist.
        if row is None:
            return None

        # Converts the database result into a User object.
        return User(**dict(row))

    def create_session(
        self,
        token: str,
        user_id: int,
        csrf_token: str,
        created_at: str,
        expires_at: str,
    ) -> None:
        """Store a new login session."""

        with self.connect() as connection:
            # Saves the session token and its expiration time.
            connection.execute(
                """
                INSERT INTO sessions
                    (
                        token,
                        user_id,
                        csrf_token,
                        created_at,
                        expires_at
                    )
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    token,
                    user_id,
                    csrf_token,
                    created_at,
                    expires_at,
                ),
            )

    def get_session(
        self,
        token: str,
        now: str,
    ) -> Optional[sqlite3.Row]:
        """Return a session when it is still active."""

        with self.connect() as connection:
            # Joins the session with its related user account.
            return connection.execute(
                """
                SELECT
                    sessions.token,
                    sessions.user_id,
                    sessions.csrf_token,
                    users.first_name,
                    users.last_name,
                    users.username,
                    users.email,
                    users.date_of_birth
                FROM sessions
                JOIN users
                    ON users.id = sessions.user_id
                WHERE sessions.token = ?
                  AND sessions.expires_at > ?
                """,
                (token, now),
            ).fetchone()

    def delete_session(self, token: str) -> None:
        """Delete one login session."""

        with self.connect() as connection:
            # Removes the session that matches the supplied token.
            connection.execute(
                "DELETE FROM sessions WHERE token = ?",
                (token,),
            )

    def delete_expired_sessions(self, now: str) -> None:
        """Delete sessions that are no longer active."""

        with self.connect() as connection:
            # Removes every session that has reached its expiration time.
            connection.execute(
                "DELETE FROM sessions WHERE expires_at <= ?",
                (now,),
            )

    def list_inventory(
        self,
        user_id: int,
    ) -> list[InventoryItem]:
        """Return inventory items owned by one user."""

        with self.connect() as connection:
            # Retrieves only items connected to the signed in user.
            rows = connection.execute(
                """
                SELECT
                    id,
                    user_id,
                    name,
                    quantity,
                    low_stock_threshold,
                    created_at,
                    updated_at
                FROM inventory_items
                WHERE user_id = ?
                ORDER BY name COLLATE NOCASE ASC
                """,
                (user_id,),
            ).fetchall()

        # Converts every database row into an InventoryItem object.
        return [
            InventoryItem(**dict(row))
            for row in rows
        ]

    def get_inventory_item(
        self,
        item_id: int,
        user_id: int,
    ) -> Optional[InventoryItem]:
        """Return an item only when it belongs to the user."""

        with self.connect() as connection:
            # Checks both the item ID and owner ID.
            row = connection.execute(
                """
                SELECT
                    id,
                    user_id,
                    name,
                    quantity,
                    low_stock_threshold,
                    created_at,
                    updated_at
                FROM inventory_items
                WHERE id = ?
                  AND user_id = ?
                """,
                (item_id, user_id),
            ).fetchone()

        # Converts the result into an InventoryItem when found.
        return InventoryItem(**dict(row)) if row else None

    def add_inventory_item(
        self,
        user_id: int,
        name: str,
        quantity: int,
        low_stock_threshold: int,
        created_at: str,
    ) -> int:
        """Add an inventory item for one user."""

        with self.connect() as connection:
            # Safely inserts the new inventory information.
            cursor = connection.execute(
                """
                INSERT INTO inventory_items
                    (
                        user_id,
                        name,
                        quantity,
                        low_stock_threshold,
                        created_at,
                        updated_at
                    )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    user_id,
                    name,
                    quantity,
                    low_stock_threshold,
                    created_at,
                    created_at,
                ),
            )

            # Returns the ID created for the new item.
            return int(cursor.lastrowid)

    def update_inventory_item(
        self,
        item_id: int,
        user_id: int,
        name: str,
        quantity: int,
        low_stock_threshold: int,
        updated_at: str,
    ) -> bool:
        """Update an inventory item owned by the user."""

        with self.connect() as connection:
            # Updates the item only when it belongs to the supplied user.
            cursor = connection.execute(
                """
                UPDATE inventory_items
                SET
                    name = ?,
                    quantity = ?,
                    low_stock_threshold = ?,
                    updated_at = ?
                WHERE id = ?
                  AND user_id = ?
                """,
                (
                    name,
                    quantity,
                    low_stock_threshold,
                    updated_at,
                    item_id,
                    user_id,
                ),
            )

            # Returns true when exactly one item was updated.
            return cursor.rowcount == 1

    def delete_inventory_item(
        self,
        item_id: int,
        user_id: int,
    ) -> bool:
        """Delete an inventory item owned by the user."""

        with self.connect() as connection:
            # Deletes the item only when the owner ID also matches.
            cursor = connection.execute(
                """
                DELETE FROM inventory_items
                WHERE id = ?
                  AND user_id = ?
                """,
                (item_id, user_id),
            )

            # Returns true when exactly one item was deleted.
            return cursor.rowcount == 1