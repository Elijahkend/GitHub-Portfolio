# AppInventory Web Enhancement

This project is the Software Design and Engineering enhancement for CS 499. It converts the original Android inventory application into a browser based Python application.

## Main improvements

1. Web based login, registration, dashboard, and inventory management
2. Separate interface, service, validation, security, and database layers
3. Password hashing with PBKDF2 and a unique salt
4. Server side sessions with protected cookies
5. CSRF protection for forms that change data
6. User specific inventory access on every read, update, and delete request
7. Parameterized SQLite queries
8. Add, edit, and delete inventory features
9. Low stock and out of stock dashboard alerts
10. Input validation, error messages, and unit tests

## Run the application

The application uses only the Python standard library and does not require third party packages.

1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Run `python app.py`.
4. Open `http://127.0.0.1:8000` in a browser.

The database file is created automatically during the first run.

## Run the tests

Run `python -m unittest discover -s tests -v` from this folder.

## Project structure

`app.py` handles HTTP routes and responses.

`services.py` contains authentication and inventory business rules.

`database.py` contains parameterized SQLite operations.

`validators.py` contains reusable validation rules.

`security.py` contains password, session, and CSRF helpers.

`templates.py` creates the web pages.

`schema.sql` defines the database structure.

`static/styles.css` contains the responsive page design.

`tests/test_services.py` verifies security, validation, and user data separation.
