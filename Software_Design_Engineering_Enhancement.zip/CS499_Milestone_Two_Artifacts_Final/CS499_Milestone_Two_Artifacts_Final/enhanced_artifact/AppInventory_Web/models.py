"""
AppInventory Web Enhancement
Author: Elija Kwembe
Date: July 06, 2026
Course: CS 499 Computer Science Capstone
Purpose: Define data models shared by the application layers.
"""

# Imports dataclass to create simple data objects.
from dataclasses import dataclass


# Makes the User object easy to create and prevents its values from changing.
@dataclass(frozen=True)
class User:
    """Stores information for one registered user."""

    # Unique ID assigned to the user.
    id: int

    # User's first name.
    first_name: str

    # User's last name.
    last_name: str

    # Username used to sign in.
    username: str

    # Email connected to the account.
    email: str

    # User's date of birth.
    date_of_birth: str


# Makes the InventoryItem object easy to create and prevents its values from changing.
@dataclass(frozen=True)
class InventoryItem:
    """Stores information for one inventory item."""

    # Unique ID assigned to the item.
    id: int

    # ID of the user who owns the item.
    user_id: int

    # Name of the inventory item.
    name: str

    # Current number of items available.
    quantity: int

    # Quantity that triggers a low stock warning.
    low_stock_threshold: int

    # Date and time when the item was created.
    created_at: str

    # Date and time when the item was last updated.
    updated_at: str

    @property
    def stock_status(self) -> str:
        """Return the current stock level message."""

        # Returns out of stock when no items are available.
        if self.quantity == 0:
            return "Out of stock"

        # Returns low stock when the quantity reaches the warning level.
        if self.quantity <= self.low_stock_threshold:
            return "Low stock"

        # Returns in stock when the quantity is above the warning level.
        return "In stock"